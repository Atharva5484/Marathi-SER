import sys
try:
    from datasets import load_dataset
except ImportError:
    print("datasets library not installed yet")
    sys.exit(0)

try:
    print("Loading Singhchandann/all_nli_marathi dataset info...")
    # Load dataset with streaming to just get the features without downloading the whole audio
    ds = load_dataset("Singhchandann/all_nli_marathi", streaming=True)
    
    print("\nDataset splits:")
    print(list(ds.keys()))
    
    # Get the features of the first split
    first_split = list(ds.keys())[0]
    print(f"\nFeatures of {first_split}:")
    print(ds[first_split].features)
    
    # Print the first row
    print("\nFirst row sample (excluding raw audio data):")
    row = next(iter(ds[first_split]))
    for key, val in row.items():
        if key == 'audio':
            print(f"audio: {val.keys()} - (raw data omitted)")
        else:
            print(f"{key}: {val}")
            
except Exception as e:
    print(f"Error loading dataset: {e}")
