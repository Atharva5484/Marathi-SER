import os
import shutil
from pathlib import Path
import logging
from tqdm import tqdm
import torch
import soundfile as sf
from transformers import pipeline

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("pseudo_labeler")

def label_data(unlabeled_dir="data/unlabeled", labeled_dir="data/labeled"):
    unlabeled_path = Path(unlabeled_dir)
    labeled_path = Path(labeled_dir)
    
    if not unlabeled_path.exists():
        logger.error(f"Unlabeled directory {unlabeled_dir} does not exist.")
        return
        
    wav_files = list(unlabeled_path.glob("*.wav"))
    if not wav_files:
        logger.error(f"No .wav files found in {unlabeled_dir}.")
        return
        
    logger.info(f"Found {len(wav_files)} files. Initializing emotion classifier...")
    
    device = 0 if torch.cuda.is_available() else -1
    classifier = pipeline("audio-classification", model="superb/wav2vec2-base-superb-er", device=device)
    
    label_map = {
        "neu": "neutral",
        "hap": "happiness",
        "ang": "anger",
        "sad": "sadness"
    }
    
    counts = {e: 0 for e in label_map.values()}
    counts["error"] = 0
    
    logger.info("Starting pseudo-labeling. This may take a while...")
    
    for wav_file in tqdm(wav_files):
        try:
            # Read audio manually to avoid ffmpeg dependency in transformers
            audio, sr = sf.read(str(wav_file))
            
            # Convert to mono if stereo
            if len(audio.shape) > 1:
                audio = audio.mean(axis=1)
                
            input_dict = {"raw": audio, "sampling_rate": sr}
            
            result = classifier(input_dict)
            top_label = result[0]['label'].lower()
            mapped_emotion = label_map.get(top_label, "neutral")
            
            dest_dir = labeled_path / mapped_emotion
            dest_dir.mkdir(parents=True, exist_ok=True)
            
            dest_path = dest_dir / wav_file.name
            shutil.move(str(wav_file), str(dest_path))
            
            counts[mapped_emotion] += 1
            
        except Exception as e:
            logger.error(f"Error processing {wav_file.name}: {e}")
            counts["error"] += 1
            
    logger.info("\nPseudo-labeling complete!")
    logger.info("Emotion distribution:")
    for emotion, count in counts.items():
        if count > 0:
            logger.info(f"  {emotion}: {count} files")

if __name__ == "__main__":
    label_data()
