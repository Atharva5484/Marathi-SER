"""
Marathi Speech Emotion Recognition – Dataset & Preprocessing Pipeline
=====================================================================
Provides:
  - AudioPreprocessor  : VAD, pre-emphasis, denoising, resampling, framing
  - DataAugmentor      : pitch shift, time-stretch, noise, SpecAugment
  - MarathiSERDataset  : PyTorch Dataset for emotion-labelled wav files
  - prepare_data_from_zip : extracts the user's raw zips into a labelable folder
  - create_data_loaders   : builds stratified train / val / test DataLoaders
"""

import os
import csv
import logging
import random
import shutil
import zipfile
from pathlib import Path
from collections import Counter
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn.functional as F
import torchaudio
import torchaudio.transforms as T
from torch.utils.data import Dataset, DataLoader, Subset

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SAMPLE_RATE = 16000
MAX_AUDIO_SEC = 5.0          # maximum clip length in seconds
MAX_AUDIO_SAMPLES = int(SAMPLE_RATE * MAX_AUDIO_SEC)
EMOTION_LABELS = ["anger", "happiness", "sadness", "neutral"]
EMOTION_TO_IDX = {e: i for i, e in enumerate(EMOTION_LABELS)}


# ============================================================================
# Audio Pre-processing
# ============================================================================

class AudioPreprocessor:
    """
    Pre-processing pipeline applied to every audio file:
      1. Load & resample to 16 kHz mono
      2. Pre-emphasis (coefficient 0.97)
      3. Voice-Activity Detection (energy-based silence removal)
      4. Simple spectral-gating denoising
      5. Pad / truncate to fixed length
    """

    def __init__(
        self,
        target_sr: int = SAMPLE_RATE,
        max_seconds: float = MAX_AUDIO_SEC,
        pre_emphasis_coeff: float = 0.97,
        vad_energy_threshold: float = 0.01,
    ):
        self.target_sr = target_sr
        self.max_samples = int(target_sr * max_seconds)
        self.pre_emphasis_coeff = pre_emphasis_coeff
        self.vad_threshold = vad_energy_threshold

    def load_audio(self, path: str) -> Tuple[torch.Tensor, int]:
        """Load audio file and resample to target sample rate."""
        waveform, sr = torchaudio.load(path)
        # Convert to mono if stereo
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        # Resample if necessary
        if sr != self.target_sr:
            resampler = T.Resample(sr, self.target_sr)
            waveform = resampler(waveform)
        return waveform, self.target_sr

    def pre_emphasis(self, waveform: torch.Tensor) -> torch.Tensor:
        """Apply pre-emphasis filter: y[n] = x[n] - α * x[n-1]."""
        return torch.cat(
            [waveform[:, :1], waveform[:, 1:] - self.pre_emphasis_coeff * waveform[:, :-1]],
            dim=1,
        )

    def voice_activity_detection(self, waveform: torch.Tensor) -> torch.Tensor:
        """
        Remove leading/trailing silence using frame-level energy thresholding.
        """
        wav = waveform.squeeze(0)
        frame_len = 400  # 25 ms at 16 kHz
        hop = 160         # 10 ms
        # Compute frame energies
        n_frames = max(1, (wav.shape[0] - frame_len) // hop + 1)
        energies = []
        for i in range(n_frames):
            frame = wav[i * hop : i * hop + frame_len]
            energies.append(frame.pow(2).mean().item())
        energies = np.array(energies)
        max_energy = energies.max() if energies.max() > 0 else 1.0
        energies_norm = energies / max_energy

        # Find first and last frames above threshold
        active = np.where(energies_norm > self.vad_threshold)[0]
        if len(active) == 0:
            return waveform  # return original if all silent
        start = max(0, active[0] * hop - hop)
        end = min(wav.shape[0], (active[-1] + 1) * hop + frame_len)
        return wav[start:end].unsqueeze(0)

    def spectral_denoise(self, waveform: torch.Tensor) -> torch.Tensor:
        """
        Simple spectral gating: estimate noise floor from first 0.1s
        and subtract from the spectrum.
        """
        wav = waveform.squeeze(0)
        n_fft = 512
        hop = 256
        noise_samples = min(int(0.1 * self.target_sr), len(wav) // 4)
        if noise_samples < n_fft:
            return waveform  # Too short to denoise

        # Estimate noise spectrum from first portion
        noise_seg = wav[:noise_samples]
        noise_stft = torch.stft(
            noise_seg, n_fft=n_fft, hop_length=hop,
            return_complex=True, window=torch.hann_window(n_fft)
        )
        noise_mag = noise_stft.abs().mean(dim=-1)  # average magnitude

        # Full STFT
        window = torch.hann_window(n_fft)
        stft = torch.stft(
            wav, n_fft=n_fft, hop_length=hop,
            return_complex=True, window=window
        )
        mag = stft.abs()
        phase = stft.angle()

        # Spectral gate: subtract noise floor
        clean_mag = torch.clamp(mag - noise_mag.unsqueeze(-1) * 1.5, min=0.0)
        clean_stft = clean_mag * torch.exp(1j * phase)

        # Inverse STFT
        clean_wav = torch.istft(
            clean_stft, n_fft=n_fft, hop_length=hop, window=window,
            length=len(wav)
        )
        return clean_wav.unsqueeze(0)

    def pad_or_truncate(self, waveform: torch.Tensor) -> torch.Tensor:
        """Pad with zeros or truncate to max_samples."""
        n = waveform.shape[-1]
        if n > self.max_samples:
            return waveform[:, :self.max_samples]
        elif n < self.max_samples:
            pad_len = self.max_samples - n
            return F.pad(waveform, (0, pad_len))
        return waveform

    def __call__(self, path: str) -> torch.Tensor:
        """
        Full preprocessing pipeline.
        
        Args:
            path: Path to .wav file.
        Returns:
            Tensor of shape (1, max_samples) – preprocessed waveform.
        """
        waveform, _ = self.load_audio(path)
        waveform = self.pre_emphasis(waveform)
        waveform = self.voice_activity_detection(waveform)
        waveform = self.spectral_denoise(waveform)
        waveform = self.pad_or_truncate(waveform)
        # Normalize amplitude
        max_val = waveform.abs().max()
        if max_val > 0:
            waveform = waveform / max_val
        return waveform


# ============================================================================
# Data Augmentation
# ============================================================================

class DataAugmentor:
    """
    On-the-fly data augmentation for training:
      - Pitch shifting (±2 semitones)
      - Time stretching (0.8x – 1.2x)
      - Additive Gaussian noise (SNR 15–30 dB)
      - SpecAugment (time & frequency masking)
    
    Each augmentation is applied with a configurable probability.
    """

    def __init__(
        self,
        sample_rate: int = SAMPLE_RATE,
        prob: float = 0.2,
        pitch_range: Tuple[int, int] = (-2, 2),
        time_stretch_range: Tuple[float, float] = (0.8, 1.2),
        snr_range: Tuple[float, float] = (15.0, 30.0),
        freq_mask_param: int = 15,
        time_mask_param: int = 35,
    ):
        self.sample_rate = sample_rate
        self.prob = prob
        self.pitch_range = pitch_range
        self.time_stretch_range = time_stretch_range
        self.snr_range = snr_range
        self.freq_mask_param = freq_mask_param
        self.time_mask_param = time_mask_param

    def pitch_shift(self, waveform: torch.Tensor) -> torch.Tensor:
        """Shift pitch by a random number of semitones (disabled for performance)."""
        return waveform

    def time_stretch(self, waveform: torch.Tensor) -> torch.Tensor:
        """Stretch or compress audio in time domain."""
        if random.random() > self.prob:
            return waveform
        rate = random.uniform(*self.time_stretch_range)
        orig_len = waveform.shape[-1]
        # Simple resampling-based time stretch
        new_len = int(orig_len * rate)
        stretched = F.interpolate(
            waveform.unsqueeze(0), size=new_len, mode="linear", align_corners=False
        ).squeeze(0)
        # Pad or truncate to original length
        if stretched.shape[-1] > orig_len:
            stretched = stretched[:, :orig_len]
        else:
            stretched = F.pad(stretched, (0, orig_len - stretched.shape[-1]))
        return stretched

    def add_noise(self, waveform: torch.Tensor) -> torch.Tensor:
        """Add Gaussian noise at a random SNR."""
        if random.random() > self.prob:
            return waveform
        snr_db = random.uniform(*self.snr_range)
        signal_power = waveform.pow(2).mean()
        noise_power = signal_power / (10 ** (snr_db / 10.0))
        noise = torch.randn_like(waveform) * noise_power.sqrt()
        return waveform + noise

    def spec_augment(self, waveform: torch.Tensor) -> torch.Tensor:
        """
        Apply SpecAugment-style masking in the time-frequency domain.
        Operates on a mel spectrogram then inverts approximately via Griffin-Lim.
        For efficiency, we apply masking by zeroing random time segments in the waveform.
        """
        if random.random() > self.prob:
            return waveform
        wav = waveform.clone()
        n = wav.shape[-1]

        # Time masking: zero out a random contiguous segment
        mask_len = random.randint(1, min(self.time_mask_param * 160, n // 4))
        start = random.randint(0, max(0, n - mask_len))
        wav[:, start:start + mask_len] = 0.0

        return wav

    def __call__(self, waveform: torch.Tensor) -> torch.Tensor:
        """Apply all augmentations (each with its own probability)."""
        waveform = self.pitch_shift(waveform)
        waveform = self.time_stretch(waveform)
        waveform = self.add_noise(waveform)
        waveform = self.spec_augment(waveform)
        return waveform


# ============================================================================
# PyTorch Dataset
# ============================================================================

class MarathiSERDataset(Dataset):
    """
    Dataset for Marathi Speech Emotion Recognition.
    
    Expected directory structure:
        data_dir/
            anger/
                file1.wav
                file2.wav
            happiness/
                ...
            sadness/
                ...
            fear/
                ...
            neutral/
                ...
            surprise/
                ...
    
    Each subfolder name is used as the emotion label.
    """

    def __init__(
        self,
        data_dir: str,
        augment: bool = False,
        max_audio_sec: float = MAX_AUDIO_SEC,
        sample_rate: int = SAMPLE_RATE,
    ):
        self.data_dir = Path(data_dir)
        self.augment = augment
        self.preprocessor = AudioPreprocessor(
            target_sr=sample_rate, max_seconds=max_audio_sec
        )
        self.augmentor = DataAugmentor(sample_rate=sample_rate) if augment else None

        self.samples: List[Tuple[str, int]] = []  # (file_path, label_idx)
        self.class_counts: Dict[int, int] = {}

        self._scan_directory()
        logger.info(
            f"MarathiSERDataset: {len(self.samples)} samples from {self.data_dir} "
            f"(augment={augment})"
        )
        for emo, idx in EMOTION_TO_IDX.items():
            count = self.class_counts.get(idx, 0)
            logger.info(f"  {emo}: {count} samples")

    def _scan_directory(self) -> None:
        """Scan the data directory for emotion-labelled wav files."""
        if not self.data_dir.exists():
            logger.warning(f"Data directory not found: {self.data_dir}")
            return
        for emotion_dir in sorted(self.data_dir.iterdir()):
            if not emotion_dir.is_dir():
                continue
            emotion_name = emotion_dir.name.lower()
            if emotion_name not in EMOTION_TO_IDX:
                logger.warning(f"Skipping unknown emotion folder: {emotion_name}")
                continue
            label_idx = EMOTION_TO_IDX[emotion_name]
            count = 0
            for wav_file in sorted(emotion_dir.glob("*.wav")):
                self.samples.append((str(wav_file), label_idx))
                count += 1
            self.class_counts[label_idx] = count

    def get_class_weights(self) -> torch.Tensor:
        """
        Compute inverse-frequency class weights for handling imbalanced data.
        
        Returns:
            Tensor of shape (num_classes,) with weights.
        """
        total = sum(self.class_counts.values())
        n_classes = len(EMOTION_LABELS)
        weights = []
        for i in range(n_classes):
            count = self.class_counts.get(i, 0)
            if count == 0:
                count = 1 # Prevent division by zero
            w = total / (n_classes * count)
            weights.append(w)
        return torch.tensor(weights, dtype=torch.float32)

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        path, label = self.samples[idx]
        try:
            waveform = self.preprocessor(path)  # (1, max_samples)
        except Exception as e:
            logger.error(f"Error processing {path}: {e}")
            # Return a silent tensor on error
            waveform = torch.zeros(1, self.preprocessor.max_samples)

        if self.augment and self.augmentor is not None:
            waveform = self.augmentor(waveform)

        return waveform.squeeze(0), label  # (max_samples,), int


# ============================================================================
# Data Preparation from Zip Files
# ============================================================================

def prepare_data_from_zip(
    zip_paths: List[str],
    output_dir: str = "data",
) -> str:
    """
    Extract the user's zip files and create the expected folder structure.
    
    Since the original datasets have NO emotion labels, all files are placed
    into an 'unlabeled' folder. The user must manually sort them into
    emotion subfolders before training.
    
    Args:
        zip_paths: List of paths to zip files.
        output_dir: Base output directory.
    
    Returns:
        Path to the labelled data directory (to be populated by user).
    """
    output_path = Path(output_dir)
    labeled_dir = output_path / "labeled"
    unlabeled_dir = output_path / "unlabeled"

    # Create emotion folders
    for emotion in EMOTION_LABELS:
        (labeled_dir / emotion).mkdir(parents=True, exist_ok=True)
    unlabeled_dir.mkdir(parents=True, exist_ok=True)

    total_extracted = 0
    for zip_path in zip_paths:
        if not os.path.exists(zip_path):
            logger.warning(f"Zip file not found: {zip_path}")
            continue
        logger.info(f"Extracting: {zip_path}")
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                for member in zf.namelist():
                    if member.lower().endswith(".wav"):
                        # Extract to unlabeled folder with a flat name
                        filename = Path(member).name
                        # Avoid collisions by prepending parent folder name
                        parent = Path(member).parent.name
                        safe_name = f"{parent}_{filename}" if parent else filename
                        target = unlabeled_dir / safe_name
                        # Extract
                        with zf.open(member) as src, open(target, "wb") as dst:
                            shutil.copyfileobj(src, dst)
                        total_extracted += 1
        except Exception as e:
            logger.error(f"Error extracting {zip_path}: {e}")

    logger.info(f"Extracted {total_extracted} wav files to {unlabeled_dir}")

    # Create a CSV skeleton for labelling
    csv_path = output_path / "labels.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["filename", "emotion"])
        for wav_file in sorted(unlabeled_dir.glob("*.wav")):
            writer.writerow([wav_file.name, ""])  # empty emotion for user to fill

    # Print instructions
    print("\n" + "=" * 70)
    print("DATA PREPARATION COMPLETE")
    print("=" * 70)
    print(f"\nExtracted {total_extracted} audio files to:")
    print(f"  {unlabeled_dir}")
    print(f"\nLabel CSV skeleton created at:")
    print(f"  {csv_path}")
    print(f"\nTo prepare your data for training, you have two options:")
    print(f"\n  OPTION 1: Manual sorting")
    print(f"  Move wav files from '{unlabeled_dir}' into the emotion folders:")
    for emotion in EMOTION_LABELS:
        print(f"    {labeled_dir / emotion}/")
    print(f"\n  OPTION 2: Fill in the CSV")
    print(f"  Edit '{csv_path}' and assign an emotion label to each file.")
    print(f"  Then run: python dataset.py --organize-csv {csv_path}")
    print(f"\nEmotion labels: {', '.join(EMOTION_LABELS)}")
    print("=" * 70)

    return str(labeled_dir)


def organize_from_csv(csv_path: str, unlabeled_dir: str, labeled_dir: str) -> None:
    """
    Read a filled-in CSV and move files into the correct emotion folders.
    
    CSV format: filename, emotion
    """
    csv_path = Path(csv_path)
    unlabeled_dir = Path(unlabeled_dir)
    labeled_dir = Path(labeled_dir)

    moved = 0
    skipped = 0
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            filename = row["filename"].strip()
            emotion = row["emotion"].strip().lower()
            if not emotion or emotion not in EMOTION_TO_IDX:
                skipped += 1
                continue
            src = unlabeled_dir / filename
            dst = labeled_dir / emotion / filename
            if src.exists():
                shutil.move(str(src), str(dst))
                moved += 1
            else:
                logger.warning(f"File not found: {src}")
                skipped += 1

    logger.info(f"Organized {moved} files, skipped {skipped}.")


# ============================================================================
# DataLoader Creation
# ============================================================================

def create_data_loaders(
    data_dir: str,
    batch_size: int = 16,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    max_audio_sec: float = MAX_AUDIO_SEC,
    sample_rate: int = SAMPLE_RATE,
    num_workers: int = 0,
    seed: int = 42,
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    Create stratified train / val / test DataLoaders.
    
    Args:
        data_dir:       Path to labelled data (with emotion subfolders).
        batch_size:     Batch size.
        train_ratio:    Fraction for training.
        val_ratio:      Fraction for validation.
        test_ratio:     Fraction for testing.
        max_audio_sec:  Maximum audio length in seconds.
        sample_rate:    Target sample rate.
        num_workers:    DataLoader workers.
        seed:           Random seed for reproducibility.
    
    Returns:
        (train_loader, val_loader, test_loader)
    """
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, \
        "Split ratios must sum to 1.0"

    # Full dataset (no augmentation yet — we'll wrap train subset)
    full_dataset = MarathiSERDataset(
        data_dir, augment=False, max_audio_sec=max_audio_sec, sample_rate=sample_rate
    )

    if len(full_dataset) == 0:
        logger.error(
            f"No samples found in {data_dir}. "
            f"Make sure wav files are organized into emotion subfolders."
        )
        raise ValueError(f"Empty dataset at {data_dir}")

    # Stratified split
    label_indices: Dict[int, List[int]] = {}
    for idx, (_, label) in enumerate(full_dataset.samples):
        label_indices.setdefault(label, []).append(idx)

    rng = random.Random(seed)
    train_indices, val_indices, test_indices = [], [], []

    for label, indices in label_indices.items():
        rng.shuffle(indices)
        n = len(indices)
        n_train = max(1, int(n * train_ratio))
        n_val = max(1, int(n * val_ratio))
        # Remaining go to test
        train_indices.extend(indices[:n_train])
        val_indices.extend(indices[n_train:n_train + n_val])
        test_indices.extend(indices[n_train + n_val:])

    logger.info(
        f"Split: train={len(train_indices)}, val={len(val_indices)}, "
        f"test={len(test_indices)}"
    )

    # Create augmented dataset for training
    train_dataset = MarathiSERDataset(
        data_dir, augment=True, max_audio_sec=max_audio_sec, sample_rate=sample_rate
    )

    train_loader = DataLoader(
        Subset(train_dataset, train_indices),
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=True,
    )
    val_loader = DataLoader(
        Subset(full_dataset, val_indices),
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )
    test_loader = DataLoader(
        Subset(full_dataset, test_indices),
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )

    return train_loader, val_loader, test_loader


# ============================================================================
# CLI Entry Point
# ============================================================================

if __name__ == "__main__":
    import argparse
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    parser = argparse.ArgumentParser(description="Marathi SER Dataset Utilities")
    subparsers = parser.add_subparsers(dest="command")

    # Prepare data from zip
    prep = subparsers.add_parser("prepare", help="Extract zip files into labelable structure")
    prep.add_argument("--zips", nargs="+", required=True, help="Paths to zip files")
    prep.add_argument("--output", default="data", help="Output directory")

    # Organize from CSV
    org = subparsers.add_parser("organize", help="Organize files from a filled CSV")
    org.add_argument("--csv", required=True, help="Path to filled labels.csv")
    org.add_argument("--unlabeled", default="data/unlabeled", help="Unlabeled dir")
    org.add_argument("--labeled", default="data/labeled", help="Labeled dir")

    # Test dataset loading
    test = subparsers.add_parser("test", help="Test loading the dataset")
    test.add_argument("--data-dir", default="data/labeled", help="Labeled data dir")
    test.add_argument("--batch-size", type=int, default=4)

    args = parser.parse_args()

    if args.command == "prepare":
        prepare_data_from_zip(args.zips, args.output)

    elif args.command == "organize":
        organize_from_csv(args.csv, args.unlabeled, args.labeled)

    elif args.command == "test":
        print("Testing dataset loading...")
        train_loader, val_loader, test_loader = create_data_loaders(
            args.data_dir, batch_size=args.batch_size
        )
        for batch_idx, (waveforms, labels) in enumerate(train_loader):
            print(f"Batch {batch_idx}: waveforms={waveforms.shape}, labels={labels}")
            if batch_idx >= 2:
                break
        print("Dataset test passed!")

    else:
        parser.print_help()
