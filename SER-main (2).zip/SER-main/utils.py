"""
Marathi Speech Emotion Recognition - Utility Functions
=====================================================
Provides helper functions for reproducibility, device management,
early stopping, visualization, and logging.
"""

import os
import random
import logging
import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------

def set_seed(seed: int = 42) -> None:
    """Set random seeds for reproducibility across numpy, torch, and random."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    logger.info(f"Random seed set to {seed}")


# ---------------------------------------------------------------------------
# Device selection
# ---------------------------------------------------------------------------

def get_device() -> torch.device:
    """Return the best available device: cuda > mps > cpu."""
    if torch.cuda.is_available():
        device = torch.device("cuda")
        logger.info(f"Using CUDA device: {torch.cuda.get_device_name(0)}")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        device = torch.device("mps")
        logger.info("Using Apple MPS device")
    else:
        device = torch.device("cpu")
        logger.info("Using CPU device")
    return device


# ---------------------------------------------------------------------------
# Parameter counting
# ---------------------------------------------------------------------------

def count_parameters(model: nn.Module) -> dict:
    """
    Return total and trainable parameter counts for a model.
    
    Returns:
        dict with 'total', 'trainable', and 'non_trainable' counts.
    """
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {
        "total": total,
        "trainable": trainable,
        "non_trainable": total - trainable,
    }


# ---------------------------------------------------------------------------
# Early Stopping
# ---------------------------------------------------------------------------

class EarlyStopping:
    """
    Monitors a metric (e.g. validation loss) and signals when training
    should stop because the metric has not improved for *patience* epochs.
    Optionally saves the best model checkpoint.
    
    Args:
        patience: Number of epochs to wait for improvement.
        min_delta: Minimum change to qualify as an improvement.
        mode: 'min' (for loss) or 'max' (for accuracy).
        save_path: If given, save the best model state dict here.
    """

    def __init__(
        self,
        patience: int = 7,
        min_delta: float = 0.0,
        mode: str = "min",
        save_path: str = None,
    ):
        self.patience = patience
        self.min_delta = min_delta
        self.mode = mode
        self.save_path = save_path

        self.counter = 0
        self.best_score = None
        self.early_stop = False

    # ---- comparison helpers ----
    def _is_improvement(self, current: float) -> bool:
        if self.best_score is None:
            return True
        if self.mode == "min":
            return current < self.best_score - self.min_delta
        return current > self.best_score + self.min_delta

    def __call__(self, metric: float, model: nn.Module = None) -> bool:
        """
        Call after each epoch with the monitored metric.

        Returns:
            True if training should stop, False otherwise.
        """
        if self._is_improvement(metric):
            self.best_score = metric
            self.counter = 0
            if self.save_path and model is not None:
                torch.save(model.state_dict(), self.save_path)
                logger.info(
                    f"EarlyStopping: metric improved to {metric:.4f}. "
                    f"Model saved to {self.save_path}"
                )
        else:
            self.counter += 1
            logger.info(
                f"EarlyStopping: no improvement for {self.counter}/{self.patience} epochs"
            )
            if self.counter >= self.patience:
                self.early_stop = True
        return self.early_stop


# ---------------------------------------------------------------------------
# Visualization helpers
# ---------------------------------------------------------------------------

def plot_confusion_matrix(
    cm: np.ndarray,
    class_names: list,
    save_path: str,
    title: str = "Confusion Matrix",
    cmap: str = "Blues",
    figsize: tuple = (8, 6),
) -> None:
    """Plot and save a confusion matrix as a heatmap."""
    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(cm, interpolation="nearest", cmap=cmap)
    ax.figure.colorbar(im, ax=ax)
    ax.set(
        xticks=np.arange(cm.shape[1]),
        yticks=np.arange(cm.shape[0]),
        xticklabels=class_names,
        yticklabels=class_names,
        title=title,
        xlabel="Predicted Label",
        ylabel="True Label",
    )
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")

    # Annotate cells
    thresh = cm.max() / 2.0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(
                j, i, format(cm[i, j], "d"),
                ha="center", va="center",
                color="white" if cm[i, j] > thresh else "black",
            )
    fig.tight_layout()
    os.makedirs(os.path.dirname(save_path) if os.path.dirname(save_path) else ".", exist_ok=True)
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info(f"Confusion matrix saved to {save_path}")


def plot_training_curves(
    train_losses: list,
    val_losses: list,
    train_accs: list,
    val_accs: list,
    save_path: str,
) -> None:
    """Plot training and validation loss/accuracy curves side by side."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    epochs = range(1, len(train_losses) + 1)

    # Loss curves
    ax1.plot(epochs, train_losses, "b-o", markersize=3, label="Train Loss")
    ax1.plot(epochs, val_losses, "r-o", markersize=3, label="Val Loss")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Loss")
    ax1.set_title("Training & Validation Loss")
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # Accuracy curves
    ax2.plot(epochs, train_accs, "b-o", markersize=3, label="Train Accuracy")
    ax2.plot(epochs, val_accs, "r-o", markersize=3, label="Val Accuracy")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Accuracy (%)")
    ax2.set_title("Training & Validation Accuracy")
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    fig.tight_layout()
    os.makedirs(os.path.dirname(save_path) if os.path.dirname(save_path) else ".", exist_ok=True)
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info(f"Training curves saved to {save_path}")


class AudioVisualizer:
    """Visualize audio waveforms, spectrograms, and acoustic features."""

    @staticmethod
    def plot_waveform(audio_path: str, save_path: str) -> None:
        """Plot the raw waveform of an audio file."""
        import torchaudio
        waveform, sr = torchaudio.load(audio_path)
        waveform = waveform[0].numpy()  # mono

        fig, ax = plt.subplots(figsize=(12, 3))
        time_axis = np.arange(len(waveform)) / sr
        ax.plot(time_axis, waveform, linewidth=0.5)
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Amplitude")
        ax.set_title(f"Waveform — {Path(audio_path).name}")
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.close(fig)

    @staticmethod
    def plot_spectrogram(audio_path: str, save_path: str, n_mels: int = 80) -> None:
        """Plot a mel spectrogram of an audio file."""
        import torchaudio
        import torchaudio.transforms as T
        waveform, sr = torchaudio.load(audio_path)
        mel_spec = T.MelSpectrogram(sample_rate=sr, n_mels=n_mels)(waveform)
        mel_spec_db = T.AmplitudeToDB()(mel_spec)

        fig, ax = plt.subplots(figsize=(12, 4))
        im = ax.imshow(
            mel_spec_db[0].numpy(), aspect="auto", origin="lower", cmap="magma"
        )
        ax.set_xlabel("Time Frames")
        ax.set_ylabel("Mel Bin")
        ax.set_title(f"Mel Spectrogram — {Path(audio_path).name}")
        fig.colorbar(im, ax=ax, format="%+2.0f dB")
        fig.tight_layout()
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.close(fig)

    @staticmethod
    def plot_features(audio_path: str, save_path: str) -> None:
        """Plot MFCC, chroma, and spectral contrast features."""
        import torchaudio
        import torchaudio.transforms as T

        waveform, sr = torchaudio.load(audio_path)

        # MFCC
        mfcc_transform = T.MFCC(sample_rate=sr, n_mfcc=13)
        mfcc = mfcc_transform(waveform)[0].numpy()

        fig, axes = plt.subplots(2, 1, figsize=(12, 8))

        # MFCC
        im0 = axes[0].imshow(mfcc, aspect="auto", origin="lower", cmap="viridis")
        axes[0].set_title(f"MFCC — {Path(audio_path).name}")
        axes[0].set_ylabel("MFCC Coefficient")
        fig.colorbar(im0, ax=axes[0])

        # Mel spectrogram (as substitute for chroma which needs librosa)
        mel_spec = T.MelSpectrogram(sample_rate=sr, n_mels=40)(waveform)
        mel_spec_db = T.AmplitudeToDB()(mel_spec)[0].numpy()
        im1 = axes[1].imshow(mel_spec_db, aspect="auto", origin="lower", cmap="magma")
        axes[1].set_title("Mel Spectrogram")
        axes[1].set_xlabel("Time Frames")
        axes[1].set_ylabel("Mel Bin")
        fig.colorbar(im1, ax=axes[1])

        fig.tight_layout()
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.close(fig)


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

def setup_logging(log_dir: str = "logs", level: int = logging.INFO) -> None:
    """
    Configure logging to both console and a timestamped file.
    
    Args:
        log_dir: Directory for log files.
        level: Logging level.
    """
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_dir, f"training_{timestamp}.log")

    formatter = logging.Formatter(
        "%(asctime)s | %(name)-20s | %(levelname)-7s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # File handler
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(level)
    fh.setFormatter(formatter)

    # Console handler
    ch = logging.StreamHandler()
    ch.setLevel(level)
    ch.setFormatter(formatter)

    # Root logger
    root = logging.getLogger()
    root.setLevel(level)
    # Avoid adding duplicate handlers
    if not root.handlers:
        root.addHandler(fh)
        root.addHandler(ch)
    else:
        root.handlers.clear()
        root.addHandler(fh)
        root.addHandler(ch)

    logging.info(f"Logging initialised. Log file: {log_file}")
