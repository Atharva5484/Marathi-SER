"""
Marathi Speech Emotion Recognition – Training Pipeline
======================================================
Complete training loop with:
  - TrainConfig for hyperparameter management
  - Trainer class with differential learning rates, warmup, early stopping
  - Wav2Vec2 freezing/unfreezing schedule
  - Metrics computation (accuracy, precision, recall, F1, confusion matrix)
  - Checkpoint saving/loading and training curve plots
"""

import os
import json
import time
import logging
import argparse
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR, LambdaLR
from torch.utils.data import DataLoader

from model import MarathiSERModel, EMOTION_LABELS, NUM_EMOTIONS, SAMPLE_RATE
from dataset import MarathiSERDataset, create_data_loaders, EMOTION_TO_IDX
from utils import (
    set_seed, get_device, count_parameters,
    EarlyStopping, plot_confusion_matrix, plot_training_curves, setup_logging,
)
from loss import FocalLoss

logger = logging.getLogger(__name__)


# ============================================================================
# Configuration
# ============================================================================

@dataclass
class TrainConfig:
    """Training hyperparameters and paths."""
    # Data
    data_dir: str = "data/labeled"
    batch_size: int = 16
    max_audio_length: float = 5.0       # seconds
    sample_rate: int = SAMPLE_RATE
    num_workers: int = 0

    # Model
    num_emotions: int = NUM_EMOTIONS
    emotion_labels: list = field(default_factory=lambda: list(EMOTION_LABELS))
    wav2vec_model_name: str = "facebook/wav2vec2-base"

    # Training
    num_epochs: int = 50
    learning_rate: float = 2e-4
    weight_decay: float = 1e-5
    warmup_steps: int = 500
    freeze_wav2vec_epochs: int = 2      # freeze Wav2Vec2 for first N epochs
    gradient_clip_norm: float = 1.0

    # Regularization
    dropout: float = 0.1
    label_smoothing: float = 0.1

    # Saving & Logging
    model_save_dir: str = "checkpoints"
    log_dir: str = "logs"
    early_stopping_patience: int = 7

    # Splits
    train_ratio: float = 0.7
    val_ratio: float = 0.15
    test_ratio: float = 0.15

    # Seed
    seed: int = 42

    # Device (auto-detected)
    device: str = ""

    def __post_init__(self):
        if not self.device:
            self.device = str(get_device())


# ============================================================================
# Metrics
# ============================================================================

def compute_metrics(
    predictions: np.ndarray,
    ground_truth: np.ndarray,
    class_names: List[str] = None,
) -> Dict:
    """
    Compute classification metrics.
    
    Returns:
        Dict with accuracy, precision, recall, f1 (macro & weighted),
        per-class metrics, and confusion matrix.
    """
    from sklearn.metrics import (
        accuracy_score, precision_score, recall_score, f1_score,
        confusion_matrix, classification_report,
    )

    if class_names is None:
        class_names = EMOTION_LABELS

    acc = accuracy_score(ground_truth, predictions)
    prec_macro = precision_score(ground_truth, predictions, average="macro", zero_division=0)
    rec_macro = recall_score(ground_truth, predictions, average="macro", zero_division=0)
    f1_macro = f1_score(ground_truth, predictions, average="macro", zero_division=0)
    f1_weighted = f1_score(ground_truth, predictions, average="weighted", zero_division=0)
    cm = confusion_matrix(ground_truth, predictions)
    report = classification_report(
        ground_truth, predictions, labels=np.arange(len(class_names)), target_names=class_names, zero_division=0
    )

    return {
        "accuracy": acc,
        "precision_macro": prec_macro,
        "recall_macro": rec_macro,
        "f1_macro": f1_macro,
        "f1_weighted": f1_weighted,
        "confusion_matrix": cm,
        "classification_report": report,
    }


# ============================================================================
# Trainer
# ============================================================================

class Trainer:
    """
    Full training pipeline for MarathiSERModel.
    
    Features:
      - Differential learning rates for Wav2Vec2 vs. other parameters
      - Linear warmup + cosine annealing schedule
      - Wav2Vec2 freezing for first N epochs, then unfreezing
      - Gradient clipping
      - Early stopping with best-model checkpointing
      - Class-weighted cross-entropy loss
    """

    def __init__(
        self,
        config: TrainConfig,
        model: MarathiSERModel,
        train_loader: DataLoader,
        val_loader: DataLoader,
        test_loader: DataLoader = None,
        class_weights: torch.Tensor = None,
    ):
        self.config = config
        self.model = model.to(config.device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
        self.device = torch.device(config.device)

        # ---- Optimizer with differential learning rates ----
        wav2vec_params = []
        branch1_params = []
        fusion_classifier_params = []

        for name, param in model.named_parameters():
            if "branch2.wav2vec" in name:
                wav2vec_params.append(param)
            elif "branch1" in name:
                branch1_params.append(param)
            else:
                fusion_classifier_params.append(param)

        self.optimizer = AdamW([
            {"params": wav2vec_params, "lr": config.learning_rate * 0.1},
            {"params": branch1_params, "lr": config.learning_rate},
            {"params": fusion_classifier_params, "lr": config.learning_rate},
        ], weight_decay=config.weight_decay)

        # ---- Scheduler: linear warmup + cosine annealing ----
        total_steps = config.num_epochs * len(train_loader)
        warmup_steps = config.warmup_steps

        def lr_lambda(step):
            if step < warmup_steps:
                return float(step) / max(1, warmup_steps)
            progress = float(step - warmup_steps) / max(1, total_steps - warmup_steps)
            return max(0.0, 0.5 * (1.0 + np.cos(np.pi * progress)))

        self.scheduler = LambdaLR(self.optimizer, lr_lambda)

        # ---- Loss ----
        if class_weights is not None:
            class_weights = class_weights.to(self.device)
        self.criterion = FocalLoss(
            weight=class_weights,
            gamma=2.0,
            label_smoothing=config.label_smoothing,
        )

        # ---- Early stopping ----
        os.makedirs(config.model_save_dir, exist_ok=True)
        best_model_path = os.path.join(config.model_save_dir, "best_model.pt")
        self.early_stopping = EarlyStopping(
            patience=config.early_stopping_patience,
            mode="max",
            save_path=best_model_path,
        )

        # ---- Tracking ----
        self.train_losses: List[float] = []
        self.val_losses: List[float] = []
        self.train_accs: List[float] = []
        self.val_accs: List[float] = []
        self.current_epoch = 0

    # -----------------------------------------------------------------
    # Training one epoch
    # -----------------------------------------------------------------

    def train_one_epoch(self) -> Tuple[float, float]:
        """Train for one epoch. Returns (avg_loss, accuracy_pct)."""
        self.model.train()
        total_loss = 0.0
        correct = 0
        total = 0

        for batch_idx, (waveforms, labels) in enumerate(self.train_loader):
            waveforms = waveforms.to(self.device)
            labels = labels.to(self.device)

            self.optimizer.zero_grad()
            logits = self.model(waveforms)
            loss = self.criterion(logits, labels)
            loss.backward()

            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(
                self.model.parameters(), self.config.gradient_clip_norm
            )

            self.optimizer.step()
            self.scheduler.step()

            total_loss += loss.item() * waveforms.size(0)
            preds = logits.argmax(dim=-1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)

            if (batch_idx + 1) % 10 == 0:
                lr = self.scheduler.get_last_lr()[0]
                logger.debug(
                    f"  Batch {batch_idx + 1}/{len(self.train_loader)} | "
                    f"Loss: {loss.item():.4f} | LR: {lr:.6f}"
                )

        avg_loss = total_loss / max(total, 1)
        accuracy = 100.0 * correct / max(total, 1)
        return avg_loss, accuracy

    # -----------------------------------------------------------------
    # Validation
    # -----------------------------------------------------------------

    @torch.no_grad()
    def validate(self) -> Tuple[float, float, Dict]:
        """Validate on the val set. Returns (avg_loss, accuracy_pct, metrics_dict)."""
        self.model.eval()
        total_loss = 0.0
        all_preds = []
        all_labels = []

        for waveforms, labels in self.val_loader:
            waveforms = waveforms.to(self.device)
            labels = labels.to(self.device)

            logits = self.model(waveforms)
            loss = self.criterion(logits, labels)

            total_loss += loss.item() * waveforms.size(0)
            preds = logits.argmax(dim=-1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

        avg_loss = total_loss / max(len(all_labels), 1)
        metrics = compute_metrics(
            np.array(all_preds), np.array(all_labels), self.config.emotion_labels
        )
        return avg_loss, metrics["accuracy"] * 100, metrics

    # -----------------------------------------------------------------
    # Test
    # -----------------------------------------------------------------

    @torch.no_grad()
    def test(self) -> Dict:
        """Evaluate on the test set. Returns detailed metrics."""
        if self.test_loader is None:
            logger.warning("No test loader provided.")
            return {}

        self.model.eval()
        all_preds = []
        all_labels = []

        for waveforms, labels in self.test_loader:
            waveforms = waveforms.to(self.device)
            labels = labels.to(self.device)

            logits = self.model(waveforms)
            preds = logits.argmax(dim=-1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

        metrics = compute_metrics(
            np.array(all_preds), np.array(all_labels), self.config.emotion_labels
        )
        return metrics

    # -----------------------------------------------------------------
    # Full training loop
    # -----------------------------------------------------------------

    def train(self) -> Dict:
        """
        Full training loop with early stopping, checkpoint saving,
        Wav2Vec2 freeze/unfreeze schedule, and logging.
        
        Returns:
            Final test metrics dict.
        """
        logger.info("=" * 60)
        logger.info("Starting training")
        logger.info("=" * 60)
        logger.info(f"Config: {json.dumps(asdict(self.config), indent=2, default=str)}")

        param_info = count_parameters(self.model)
        logger.info(
            f"Model parameters: total={param_info['total']:,}, "
            f"trainable={param_info['trainable']:,}"
        )

        # Freeze Wav2Vec2 initially
        if self.config.freeze_wav2vec_epochs > 0:
            self.model.branch2.freeze_encoder()
            logger.info(
                f"Wav2Vec2 frozen for first {self.config.freeze_wav2vec_epochs} epochs"
            )

        best_val_acc = 0.0
        start_time = time.time()

        for epoch in range(1, self.config.num_epochs + 1):
            self.current_epoch = epoch
            epoch_start = time.time()

            # Unfreeze Wav2Vec2 after N epochs
            if epoch == self.config.freeze_wav2vec_epochs + 1:
                self.model.branch2.unfreeze_encoder()
                logger.info(f"Epoch {epoch}: Wav2Vec2 unfrozen for fine-tuning")

            # Train
            train_loss, train_acc = self.train_one_epoch()
            self.train_losses.append(train_loss)
            self.train_accs.append(train_acc)

            # Validate
            val_loss, val_acc, val_metrics = self.validate()
            self.val_losses.append(val_loss)
            self.val_accs.append(val_acc)

            epoch_time = time.time() - epoch_start
            logger.info(
                f"Epoch {epoch:3d}/{self.config.num_epochs} | "
                f"Train Loss: {train_loss:.4f} Acc: {train_acc:.2f}% | "
                f"Val Loss: {val_loss:.4f} Acc: {val_acc:.2f}% | "
                f"Time: {epoch_time:.1f}s"
            )

            if val_acc > best_val_acc:
                best_val_acc = val_acc

            # Early stopping
            if self.early_stopping(val_acc, self.model):
                logger.info(f"Early stopping triggered at epoch {epoch}")
                break

        total_time = time.time() - start_time
        logger.info(f"\nTraining complete in {total_time / 60:.1f} minutes")
        logger.info(f"Best validation accuracy: {best_val_acc:.2f}%")

        # Save training curves
        os.makedirs(self.config.log_dir, exist_ok=True)
        curves_path = os.path.join(self.config.log_dir, "training_curves.png")
        plot_training_curves(
            self.train_losses, self.val_losses,
            self.train_accs, self.val_accs,
            curves_path,
        )

        # Load best model and test
        best_path = os.path.join(self.config.model_save_dir, "best_model.pt")
        if os.path.exists(best_path):
            self.model.load_state_dict(torch.load(best_path, map_location=self.device))
            logger.info(f"Loaded best model from {best_path}")

        test_metrics = self.test()
        if test_metrics:
            logger.info("\n" + "=" * 60)
            logger.info("TEST SET RESULTS")
            logger.info("=" * 60)
            logger.info(f"Accuracy:         {test_metrics['accuracy']:.4f}")
            logger.info(f"F1 (macro):       {test_metrics['f1_macro']:.4f}")
            logger.info(f"F1 (weighted):    {test_metrics['f1_weighted']:.4f}")
            logger.info(f"Precision (macro):{test_metrics['precision_macro']:.4f}")
            logger.info(f"Recall (macro):   {test_metrics['recall_macro']:.4f}")
            logger.info(f"\n{test_metrics['classification_report']}")

            # Confusion matrix
            cm_path = os.path.join(self.config.log_dir, "confusion_matrix.png")
            plot_confusion_matrix(
                test_metrics["confusion_matrix"],
                self.config.emotion_labels,
                cm_path,
            )

            # Save metrics to JSON
            metrics_path = os.path.join(self.config.log_dir, "test_metrics.json")
            saveable = {
                k: v.tolist() if isinstance(v, np.ndarray) else v
                for k, v in test_metrics.items()
            }
            with open(metrics_path, "w") as f:
                json.dump(saveable, f, indent=2)
            logger.info(f"Metrics saved to {metrics_path}")

        return test_metrics

    # -----------------------------------------------------------------
    # Checkpointing
    # -----------------------------------------------------------------

    def save_checkpoint(self, path: str = None) -> str:
        """Save a full training checkpoint."""
        if path is None:
            path = os.path.join(
                self.config.model_save_dir, f"checkpoint_epoch_{self.current_epoch}.pt"
            )
        os.makedirs(os.path.dirname(path), exist_ok=True)
        checkpoint = {
            "epoch": self.current_epoch,
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "scheduler_state_dict": self.scheduler.state_dict(),
            "train_losses": self.train_losses,
            "val_losses": self.val_losses,
            "train_accs": self.train_accs,
            "val_accs": self.val_accs,
            "config": asdict(self.config),
        }
        torch.save(checkpoint, path)
        logger.info(f"Checkpoint saved to {path}")
        return path

    def load_checkpoint(self, path: str) -> None:
        """Load a training checkpoint and resume."""
        checkpoint = torch.load(path, map_location=self.device)
        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
        self.current_epoch = checkpoint["epoch"]
        self.train_losses = checkpoint.get("train_losses", [])
        self.val_losses = checkpoint.get("val_losses", [])
        self.train_accs = checkpoint.get("train_accs", [])
        self.val_accs = checkpoint.get("val_accs", [])
        logger.info(f"Checkpoint loaded from {path} (epoch {self.current_epoch})")


# ============================================================================
# Main entry point
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Train Marathi Speech Emotion Recognition Model"
    )
    parser.add_argument("--data-dir", default="data/labeled", help="Labeled data directory")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--freeze-epochs", type=int, default=5)
    parser.add_argument("--patience", type=int, default=7)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--checkpoint", default=None, help="Resume from checkpoint")
    parser.add_argument("--save-dir", default="checkpoints")
    parser.add_argument("--log-dir", default="logs")
    args = parser.parse_args()

    # Setup
    config = TrainConfig(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        num_epochs=args.epochs,
        learning_rate=args.lr,
        freeze_wav2vec_epochs=args.freeze_epochs,
        early_stopping_patience=args.patience,
        seed=args.seed,
        model_save_dir=args.save_dir,
        log_dir=args.log_dir,
    )

    setup_logging(config.log_dir)
    set_seed(config.seed)

    logger.info("Marathi Speech Emotion Recognition — Training")
    logger.info(f"Device: {config.device}")

    # Data
    logger.info("Loading data...")
    train_loader, val_loader, test_loader = create_data_loaders(
        data_dir=config.data_dir,
        batch_size=config.batch_size,
        train_ratio=config.train_ratio,
        val_ratio=config.val_ratio,
        test_ratio=config.test_ratio,
        max_audio_sec=config.max_audio_length,
        sample_rate=config.sample_rate,
        num_workers=config.num_workers,
        seed=config.seed,
    )

    # Get class weights from training dataset
    train_dataset = train_loader.dataset
    # Navigate through Subset wrapper to get class weights
    if hasattr(train_dataset, "dataset"):
        class_weights = train_dataset.dataset.get_class_weights()
    else:
        class_weights = train_dataset.get_class_weights()
    logger.info(f"Class weights: {class_weights.tolist()}")

    # Model
    model = MarathiSERModel(
        num_emotions=config.num_emotions,
        sample_rate=config.sample_rate,
        dropout=config.dropout,
        freeze_wav2vec=True,
    )

    # Load RAVDESS pre-trained features if available
    ravdess_path = os.path.join(config.model_save_dir, "best_model_ravdess.pt")
    if os.path.exists(ravdess_path):
        logger.info(f"Loading pre-trained RAVDESS features from {ravdess_path}...")
        try:
            old_state_dict = torch.load(ravdess_path, map_location=config.device)
            if "model_state_dict" in old_state_dict:
                old_state = old_state_dict["model_state_dict"]
            else:
                old_state = old_state_dict
            
            # Map classifier weights if shape mismatched
            new_state = {}
            for k, v in old_state.items():
                if k == "classifier.8.weight" and v.shape[0] != config.num_emotions:
                    logger.info(f"Mapping classifier layer weight {v.shape} to {config.num_emotions} classes...")
                    new_v = torch.zeros(config.num_emotions, v.shape[1])
                    new_v[0] = v[0]  # anger
                    new_v[1] = v[1]  # happiness
                    new_v[2] = v[2]  # sadness
                    if v.shape[0] > 4:
                        new_v[3] = v[4]  # neutral (from index 4)
                    else:
                        new_v[3] = v[3]  # fallback
                    new_state[k] = new_v
                elif k == "classifier.8.bias" and v.shape[0] != config.num_emotions:
                    logger.info(f"Mapping classifier layer bias {v.shape} to {config.num_emotions} classes...")
                    new_v = torch.zeros(config.num_emotions)
                    new_v[0] = v[0]  # anger
                    new_v[1] = v[1]  # happiness
                    new_v[2] = v[2]  # sadness
                    if v.shape[0] > 4:
                        new_v[3] = v[4]  # neutral (from index 4)
                    else:
                        new_v[3] = v[3]  # fallback
                    new_state[k] = new_v
                else:
                    new_state[k] = v
            
            # Load into model
            model.load_state_dict(new_state, strict=False)
            logger.info("Pre-trained RAVDESS features loaded successfully (non-strict).")
        except Exception as e:
            logger.warning(f"Failed to load RAVDESS features: {e}. Training from scratch.")

    # Trainer
    trainer = Trainer(
        config=config,
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        test_loader=test_loader,
        class_weights=class_weights,
    )

    # Resume if checkpoint provided
    if args.checkpoint and os.path.exists(args.checkpoint):
        trainer.load_checkpoint(args.checkpoint)

    # Train
    test_metrics = trainer.train()

    # Save final checkpoint
    trainer.save_checkpoint(os.path.join(config.model_save_dir, "final_checkpoint.pt"))

    logger.info("Training pipeline complete.")


if __name__ == "__main__":
    main()
