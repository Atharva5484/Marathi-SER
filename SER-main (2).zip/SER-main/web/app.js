document.addEventListener("DOMContentLoaded", () => {
    // Current Active States
    let currentPredictionsPage = 1;
    let predictionsPerPage = 15;
    let loadedPredictionsData = [];
    
    // Audio State
    let audioContext = null;
    let analyser = null;
    let sourceNode = null;
    let animationId = null;
    let selectedAudioFile = null;
    let isUploadedMode = false;
    
    // Elements Cache
    const navButtons = document.querySelectorAll(".nav-btn");
    const sections = document.querySelectorAll(".dashboard-section");
    const subTabButtons = document.querySelectorAll(".sub-tab-btn");
    const subTabContents = document.querySelectorAll(".sub-tab-content");
    
    // API base URLs
    const API_METRICS = "/api/metrics";
    const API_PREDICTIONS = "/api/predictions";
    const API_SAMPLES = "/api/samples";
    const API_PREDICT = "/api/predict";

    // Emotion Color Mapping (Must match CSS custom variables)
    const EMOTION_COLORS = {
        anger: "#ff3366",
        happiness: "#ffb300",
        sadness: "#00b0ff",
        fear: "#d500f9",
        neutral: "#90a4ae",
        surprise: "#00e676"
    };

    /* ============================================================================
       1. Navigation & Tab Switching
       ============================================================================ */
    navButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const targetId = btn.getAttribute("data-target");
            
            navButtons.forEach(b => b.classList.remove("active"));
            sections.forEach(s => s.classList.remove("active"));
            
            btn.classList.add("active");
            document.getElementById(targetId).classList.add("active");

            // Stop audio if navigating away from playground
            if (targetId !== "section-playground") {
                stopAudio();
            }
        });
    });

    subTabButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const targetId = btn.getAttribute("data-subtarget");
            
            subTabButtons.forEach(b => b.classList.remove("active"));
            subTabContents.forEach(c => c.classList.remove("active"));
            
            btn.classList.add("active");
            document.getElementById(targetId).classList.add("active");
        });
    });

    /* ============================================================================
       2. Fetch & Render Overview Dashboard Metrics
       ============================================================================ */
    function loadMetrics() {
        fetch(API_METRICS)
            .then(res => res.json())
            .then(data => {
                // Update Overview Cards
                document.getElementById("val-accuracy").innerText = `${(data.accuracy * 100).toFixed(2)}%`;
                document.getElementById("val-f1").innerText = data.macro_avg.f1_score.toFixed(3);
                document.getElementById("val-samples").innerText = data.total_support;
                
                // Draw Chart.js Bar Chart
                renderOverviewChart(data.classes);
                
                // Render Classification Table
                renderClassificationReportTable(data.classes, data.macro_avg, data.weighted_avg);
            })
            .catch(err => {
                console.error("Error loading metrics API:", err);
            });
    }

    let overviewChartInstance = null;
    function renderOverviewChart(classesData) {
        const ctx = document.getElementById("overview-chart").getContext("2d");
        
        // Prepare Chart Data
        const labels = Object.keys(classesData).map(c => c.toUpperCase());
        const f1Scores = Object.values(classesData).map(c => c.f1_score);
        const supports = Object.values(classesData).map(c => c.support);
        const backgroundColors = Object.keys(classesData).map(c => EMOTION_COLORS[c] || "#999");
        
        if (overviewChartInstance) {
            overviewChartInstance.destroy();
        }
        
        overviewChartInstance = new Chart(ctx, {
            type: "bar",
            data: {
                labels: labels,
                datasets: [
                    {
                        label: "F1-Score (Model Accuracy per Class)",
                        data: f1Scores,
                        backgroundColor: backgroundColors,
                        borderRadius: 6,
                        yAxisID: "y-f1",
                        barPercentage: 0.6
                    },
                    {
                        label: "Support (Number of Audio Files Evaluated)",
                        data: supports,
                        type: "line",
                        borderColor: "rgba(255, 255, 255, 0.25)",
                        borderDash: [5, 5],
                        borderWidth: 2,
                        pointBackgroundColor: "#00f2fe",
                        pointRadius: 4,
                        fill: false,
                        yAxisID: "y-support"
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: "#9a98a6",
                            font: { family: "Outfit", size: 12 }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label.startsWith("F1-Score")) {
                                    return `${label}: ${context.raw.toFixed(2)}`;
                                }
                                return `${label}: ${context.raw}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { color: "rgba(255, 255, 255, 0.05)" },
                        ticks: { color: "#9a98a6", font: { family: "Outfit", size: 11, weight: 600 } }
                    },
                    "y-f1": {
                        type: "linear",
                        position: "left",
                        min: 0.0,
                        max: 1.0,
                        grid: { color: "rgba(255, 255, 255, 0.05)" },
                        ticks: { color: "#9a98a6" },
                        title: { display: true, text: "F1-Score", color: "#9a98a6" }
                    },
                    "y-support": {
                        type: "linear",
                        position: "right",
                        min: 0,
                        grid: { drawOnChartArea: false },
                        ticks: { color: "#9a98a6" },
                        title: { display: true, text: "Test Samples Count", color: "#9a98a6" }
                    }
                }
            }
        });
    }

    function renderClassificationReportTable(classesData, macroAvg, weightedAvg) {
        const tbody = document.getElementById("report-table-body");
        tbody.innerHTML = "";
        
        // Emotion Classes Rows
        Object.entries(classesData).forEach(([emotion, metrics]) => {
            const row = document.createElement("tr");
            const pct = (metrics.f1_score * 100).toFixed(0);
            const color = EMOTION_COLORS[emotion] || "#fff";
            
            row.innerHTML = `
                <td><span class="emotion-badge emotion-badge-${emotion}">${emotion}</span></td>
                <td>${metrics.precision.toFixed(2)}</td>
                <td>${metrics.recall.toFixed(2)}</td>
                <td style="font-weight: 600;">${metrics.f1_score.toFixed(2)}</td>
                <td>${metrics.support}</td>
                <td>
                    <div class="metric-spark-track">
                        <div class="metric-spark-fill" style="width: ${pct}%; background-color: ${color};"></div>
                    </div>
                    <span style="font-size: 12px; color: var(--text-secondary); margin-left: 6px;">${pct}%</span>
                </td>
            `;
            tbody.appendChild(row);
        });
        
        // Add Macro & Weighted averages
        const addSummaryRow = (label, data) => {
            const row = document.createElement("tr");
            row.style.borderTop = "2px solid rgba(255, 255, 255, 0.1)";
            row.style.backgroundColor = "rgba(255,255,255,0.01)";
            
            const pct = (data.f1_score * 100).toFixed(0);
            row.innerHTML = `
                <td style="font-weight: 700; color: #fff;">${label}</td>
                <td>${data.precision.toFixed(2)}</td>
                <td>${data.recall.toFixed(2)}</td>
                <td style="font-weight: 700; color: var(--color-primary);">${data.f1_score.toFixed(2)}</td>
                <td>${data.support}</td>
                <td>
                    <div class="metric-spark-track">
                        <div class="metric-spark-fill" style="width: ${pct}%; background: var(--grad-primary);"></div>
                    </div>
                    <span style="font-size: 12px; color: var(--color-primary); margin-left: 6px;">${pct}%</span>
                </td>
            `;
            tbody.appendChild(row);
        };
        
        addSummaryRow("Macro Average", macroAvg);
        addSummaryRow("Weighted Average", weightedAvg);
    }

    /* ============================================================================
       3. Interactive Confusion Matrix Grid Compiler
       ============================================================================ */
    function loadInteractiveConfusionMatrix() {
        // Fetch ALL predictions (request a high limit to get all test outputs)
        fetch(`${API_PREDICTIONS}?per_page=1000`)
            .then(res => res.json())
            .then(resData => {
                const predictions = resData.data;
                const emotions = ["anger", "happiness", "sadness", "fear", "neutral", "surprise"];
                
                // Initialize matrix counts
                // structure: counts[true_label][predicted_label]
                const counts = {};
                emotions.forEach(t => {
                    counts[t] = {};
                    emotions.forEach(p => {
                        counts[t][p] = 0;
                    });
                });
                
                // Aggregate counts
                predictions.forEach(p => {
                    const trueLbl = p.True_Label.toLowerCase();
                    const predLbl = p.Predicted_Label.toLowerCase();
                    if (counts[trueLbl] && counts[trueLbl].hasOwnProperty(predLbl)) {
                        counts[trueLbl][predLbl]++;
                    }
                });
                
                // Draw Interactive Grid Table
                const container = document.getElementById("interactive-cm-container");
                container.innerHTML = "";
                
                const table = document.createElement("table");
                table.className = "cm-interactive-table";
                
                // 1. Header Row (Predicted)
                const headerRow = document.createElement("tr");
                const cornerTh = document.createElement("th");
                cornerTh.className = "cm-corner-lbl";
                cornerTh.innerHTML = "True \\ Pred";
                headerRow.appendChild(cornerTh);
                
                emotions.forEach(e => {
                    const th = document.createElement("th");
                    th.innerText = e.toUpperCase().substring(0, 4);
                    th.title = e.toUpperCase();
                    headerRow.appendChild(th);
                });
                table.appendChild(headerRow);
                
                // 2. Data Rows
                emotions.forEach(trueEmotion => {
                    const row = document.createElement("tr");
                    
                    // Row label
                    const labelTd = document.createElement("td");
                    labelTd.className = "cm-label-row-header";
                    labelTd.innerText = trueEmotion.toUpperCase();
                    row.appendChild(labelTd);
                    
                    // Row sample size (sum of all predictions for this true label)
                    const totalRowSamples = Object.values(counts[trueEmotion]).reduce((a, b) => a + b, 0);
                    
                    emotions.forEach(predEmotion => {
                        const cellCount = counts[trueEmotion][predEmotion];
                        const ratio = totalRowSamples > 0 ? (cellCount / totalRowSamples) : 0;
                        const percentage = (ratio * 100).toFixed(0);
                        
                        const td = document.createElement("td");
                        td.className = "cm-cell";
                        td.innerText = cellCount;
                        
                        // Apply HSL intensity coloring based on weight ratios
                        // Diagonals are green correctness, non-diagonals are error red
                        const isCorrect = trueEmotion === predEmotion;
                        if (isCorrect) {
                            td.style.backgroundColor = `rgba(0, 230, 118, ${0.1 + ratio * 0.8})`;
                            td.style.border = `1px solid rgba(0, 230, 118, ${0.2 + ratio * 0.5})`;
                        } else {
                            td.style.backgroundColor = cellCount > 0 ? `rgba(255, 51, 102, ${0.05 + ratio * 0.7})` : "rgba(255,255,255,0.01)";
                            td.style.color = cellCount > 0 ? "#ff8fa3" : "rgba(255,255,255,0.2)";
                        }
                        
                        // Hover Tooltip details
                        td.title = `True Emotion: ${trueEmotion.toUpperCase()}\nPredicted: ${predEmotion.toUpperCase()}\nCount: ${cellCount} files (${percentage}% of true ${trueEmotion} clips)`;
                        
                        row.appendChild(td);
                    });
                    
                    table.appendChild(row);
                });
                
                container.appendChild(table);
            })
            .catch(err => {
                document.getElementById("interactive-cm-container").innerHTML = `<p class="error-text">Failed to load interactive matrix logs.</p>`;
                console.error("Error drawing Interactive Confusion Matrix:", err);
            });
    }

    /* ============================================================================
       4. Predictions Explorer (Pagination, Filters, Search)
       ============================================================================ */
    const searchInput = document.getElementById("predictions-search");
    const filterTrue = document.getElementById("filter-true");
    const filterPredicted = document.getElementById("filter-predicted");
    const sortSelect = document.getElementById("sort-predictions");
    
    const prevPageBtn = document.getElementById("btn-prev-page");
    const nextPageBtn = document.getElementById("btn-next-page");
    
    // Bind Event Listeners
    let searchTimeout = null;
    searchInput.addEventListener("input", () => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            currentPredictionsPage = 1;
            loadPredictionsList();
        }, 300);
    });

    filterTrue.addEventListener("change", () => {
        currentPredictionsPage = 1;
        loadPredictionsList();
    });

    filterPredicted.addEventListener("change", () => {
        currentPredictionsPage = 1;
        loadPredictionsList();
    });

    sortSelect.addEventListener("change", () => {
        currentPredictionsPage = 1;
        loadPredictionsList();
    });

    prevPageBtn.addEventListener("click", () => {
        if (currentPredictionsPage > 1) {
            currentPredictionsPage--;
            loadPredictionsList();
        }
    });

    nextPageBtn.addEventListener("click", () => {
        currentPredictionsPage++;
        loadPredictionsList();
    });

    function loadPredictionsList() {
        const search = searchInput.value;
        const trueLbl = filterTrue.value;
        const predLbl = filterPredicted.value;
        const [sortBy, sortOrder] = sortSelect.value.split("-");
        
        let url = `${API_PREDICTIONS}?page=${currentPredictionsPage}&per_page=${predictionsPerPage}`;
        if (search) url += `&search=${encodeURIComponent(search)}`;
        if (trueLbl) url += `&true_label=${encodeURIComponent(trueLbl)}`;
        if (predLbl) url += `&pred_label=${encodeURIComponent(predLbl)}`;
        if (sortBy) url += `&sort_by=${sortBy}&sort_order=${sortOrder}`;
        
        fetch(url)
            .then(res => res.json())
            .then(data => {
                renderPredictionsTable(data.data);
                updatePaginationControls(data.total, data.page, data.pages);
            })
            .catch(err => {
                console.error("Error loading test predictions:", err);
            });
    }

    function renderPredictionsTable(records) {
        const tbody = document.getElementById("predictions-table-body");
        tbody.innerHTML = "";
        
        if (!records || records.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted);">No records found matching filters.</td></tr>`;
            return;
        }
        
        records.forEach(r => {
            const isMatch = r.True_Label.toLowerCase() === r.Predicted_Label.toLowerCase();
            const statusHtml = isMatch 
                ? `<span class="status-indicator correct">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg> Match
                   </span>`
                : `<span class="status-indicator incorrect">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg> Error
                   </span>`;
                   
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>#${r.Sample_Index}</td>
                <td><span class="emotion-badge emotion-badge-${r.True_Label.toLowerCase()}">${r.True_Label}</span></td>
                <td><span class="emotion-badge emotion-badge-${r.Predicted_Label.toLowerCase()}">${r.Predicted_Label}</span></td>
                <td style="font-weight: 500; font-variant-numeric: tabular-nums;">${(r.Confidence * 100).toFixed(1)}%</td>
                <td>${statusHtml}</td>
            `;
            tbody.appendChild(row);
        });
    }

    function updatePaginationControls(total, page, totalPages) {
        const start = total === 0 ? 0 : (page - 1) * predictionsPerPage + 1;
        const end = Math.min(page * predictionsPerPage, total);
        
        document.getElementById("pagination-info").innerText = `Showing ${start}-${end} of ${total} samples`;
        
        prevPageBtn.disabled = page <= 1;
        nextPageBtn.disabled = page >= totalPages;
    }

    /* ============================================================================
       5. Audio Inference Playground (Modes, Playback, and Web Visualizer)
       ============================================================================ */
    const selectModeBtn = document.getElementById("btn-mode-samples");
    const uploadModeBtn = document.getElementById("btn-mode-upload");
    const sampleSelector = document.getElementById("sample-select");
    const fileInput = document.getElementById("upload-file-input");
    const dropzone = document.getElementById("dropzone");
    const runInferenceBtn = document.getElementById("btn-run-inference");
    
    const audioPlayer = document.getElementById("primary-audio");
    const playPauseBtn = document.getElementById("btn-audio-play");
    const playSvg = document.getElementById("play-svg");
    const pauseSvg = document.getElementById("pause-svg");
    const audioProgressFill = document.getElementById("audio-progress-fill");
    const audioProgressWrapper = document.getElementById("audio-progress-wrapper");
    const curTimeLbl = document.getElementById("audio-time-current");
    const durationLbl = document.getElementById("audio-time-duration");

    const resultBoxEmpty = document.getElementById("result-box-empty");
    const resultBoxOutput = document.getElementById("result-box-output");
    
    // Switch between Playground Modes
    selectModeBtn.addEventListener("click", () => {
        selectModeBtn.classList.add("active");
        uploadModeBtn.classList.remove("active");
        document.getElementById("mode-samples-content").classList.add("active");
        document.getElementById("mode-upload-content").classList.remove("active");
        isUploadedMode = false;
        resetPlayground();
    });

    uploadModeBtn.addEventListener("click", () => {
        uploadModeBtn.classList.add("active");
        selectModeBtn.classList.remove("active");
        document.getElementById("mode-upload-content").classList.add("active");
        document.getElementById("mode-samples-content").classList.remove("active");
        isUploadedMode = true;
        resetPlayground();
    });

    // Populate Sample selector dropdown
    function loadSamplesList() {
        fetch(API_SAMPLES)
            .then(res => res.json())
            .then(samples => {
                sampleSelector.innerHTML = '<option value="" disabled selected>-- Select an Audio Sample --</option>';
                samples.forEach((sample, idx) => {
                    const opt = document.createElement("option");
                    opt.value = JSON.stringify(sample);
                    opt.innerText = `Sample #${idx+1} [True emotion: ${sample.emotion.toUpperCase()} - file: ${sample.filename}]`;
                    sampleSelector.appendChild(opt);
                });
            })
            .catch(err => {
                console.error("Error loading sample wav files:", err);
            });
    }

    sampleSelector.addEventListener("change", () => {
        const sampleVal = sampleSelector.value;
        if (sampleVal) {
            const sample = JSON.parse(sampleVal);
            setupAudioSource(sample.audio_url);
            selectedAudioFile = sample;
            runInferenceBtn.disabled = false;
        }
    });

    // File Drag & Drop Logic
    dropzone.addEventListener("click", () => fileInput.click());
    
    fileInput.addEventListener("change", () => {
        handleUploadedFiles(fileInput.files);
    });

    dropzone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropzone.classList.add("dragover");
    });

    dropzone.addEventListener("dragleave", () => {
        dropzone.classList.remove("dragover");
    });

    dropzone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropzone.classList.remove("dragover");
        handleUploadedFiles(e.dataTransfer.files);
    });

    function handleUploadedFiles(files) {
        if (files.length > 0) {
            const file = files[0];
            if (!file.name.toLowerCase().endsWith(".wav")) {
                alert("Only standard WAV audio files are supported!");
                return;
            }
            
            document.getElementById("file-name-indicator").innerHTML = `📎 Selected: <strong>${file.name}</strong> (${(file.size / 1024).toFixed(0)} KB)`;
            
            const fileUrl = URL.createObjectURL(file);
            setupAudioSource(fileUrl);
            selectedAudioFile = file;
            runInferenceBtn.disabled = false;
        }
    }

    function resetPlayground() {
        stopAudio();
        selectedAudioFile = null;
        runInferenceBtn.disabled = true;
        sampleSelector.selectedIndex = 0;
        fileInput.value = "";
        document.getElementById("file-name-indicator").innerText = "No file selected (Max length 5s, 16kHz WAV recommended)";
        playPauseBtn.disabled = true;
        
        audioProgressFill.style.width = "0%";
        curTimeLbl.innerText = "0:00";
        durationLbl.innerText = "0:00";
        
        resultBoxEmpty.style.display = "flex";
        resultBoxOutput.style.display = "none";
        
        // Redraw static placeholder canvas waves
        drawStaticWave();
    }

    // Set Audio Source Element
    function setupAudioSource(url) {
        stopAudio();
        audioPlayer.src = url;
        audioPlayer.load();
        
        audioPlayer.oncanplaythrough = () => {
            playPauseBtn.disabled = false;
            // Format duration
            const duration = audioPlayer.duration;
            durationLbl.innerText = formatTime(duration);
        };
        
        audioPlayer.ontimeupdate = () => {
            const progress = (audioPlayer.currentTime / audioPlayer.duration) * 100;
            audioProgressFill.style.width = `${progress}%`;
            curTimeLbl.innerText = formatTime(audioPlayer.currentTime);
        };

        audioPlayer.onended = () => {
            playSvg.style.display = "block";
            pauseSvg.style.display = "none";
            stopVisualizer();
        };
    }

    // Custom Play / Pause triggers
    playPauseBtn.addEventListener("click", () => {
        if (audioPlayer.paused) {
            audioPlayer.play()
                .then(() => {
                    playSvg.style.display = "none";
                    pauseSvg.style.display = "block";
                    startVisualizer();
                })
                .catch(err => console.error("Playback error:", err));
        } else {
            audioPlayer.pause();
            playSvg.style.display = "block";
            pauseSvg.style.display = "none";
            stopVisualizer();
        }
    });

    // Scrub Audio progress bar click
    audioProgressWrapper.addEventListener("click", (e) => {
        if (!audioPlayer.src) return;
        const rect = audioProgressWrapper.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const ratio = clickX / rect.width;
        audioPlayer.currentTime = ratio * audioPlayer.duration;
    });

    function stopAudio() {
        if (!audioPlayer.paused) {
            audioPlayer.pause();
        }
        playSvg.style.display = "block";
        pauseSvg.style.display = "none";
        stopVisualizer();
    }

    function formatTime(secs) {
        if (isNaN(secs)) return "0:00";
        const m = Math.floor(secs / 60);
        const s = Math.floor(secs % 60);
        return `${m}:${s < 10 ? '0' : ''}${s}`;
    }

    /* ============================================================================
       6. Web Canvas Real-time Waveform visualizer
       ============================================================================ */
    const canvas = document.getElementById("wave-canvas");
    const canvasCtx = canvas.getContext("2d");
    
    // Fit canvas width to dynamic container resizing
    function resizeCanvas() {
        const rect = canvas.parentElement.getBoundingClientRect();
        canvas.width = rect.width;
    }
    window.addEventListener("resize", resizeCanvas);
    resizeCanvas();

    function drawStaticWave() {
        resizeCanvas();
        canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Draw standard cool glowing audio placeholder bars
        const barWidth = 3;
        const barGap = 3;
        const totalBars = Math.floor(canvas.width / (barWidth + barGap));
        const midY = canvas.height / 2;
        
        canvasCtx.fillStyle = "rgba(0, 242, 254, 0.15)";
        
        for (let i = 0; i < totalBars; i++) {
            // Draw static pseudo-sine amplitude
            const x = i * (barWidth + barGap);
            const amp = Math.sin(i * 0.1) * 15 + Math.cos(i * 0.05) * 5;
            const barHeight = Math.max(4, Math.abs(amp));
            
            canvasCtx.fillRect(x, midY - barHeight/2, barWidth, barHeight);
        }
        document.getElementById("visualizer-placeholder").style.display = "block";
    }
    
    // Initial draw
    drawStaticWave();

    function initAudioContext() {
        if (audioContext) return;
        
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        audioContext = new AudioContextClass();
        analyser = audioContext.createAnalyser();
        analyser.fftSize = 128; // Lower FFT size for wider visual bars
        
        sourceNode = audioContext.createMediaElementSource(audioPlayer);
        sourceNode.connect(analyser);
        analyser.connect(audioContext.destination);
    }

    function startVisualizer() {
        initAudioContext();
        if (audioContext.state === "suspended") {
            audioContext.resume();
        }
        
        document.getElementById("visualizer-placeholder").style.display = "none";
        
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        
        const draw = () => {
            animationId = requestAnimationFrame(draw);
            analyser.getByteFrequencyData(dataArray);
            
            canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
            
            const barWidth = (canvas.width / bufferLength) * 1.2;
            let x = 0;
            const midY = canvas.height / 2;
            
            for (let i = 0; i < bufferLength; i++) {
                const percent = dataArray[i] / 255;
                const barHeight = percent * canvas.height * 0.95;
                
                // Color theory gradients from primary cyan to secondary purple
                const r = Math.floor(127 * percent + 0);
                const g = Math.floor(242 * (1 - percent));
                const b = Math.floor(254);
                
                canvasCtx.fillStyle = `rgb(${r},${g},${b})`;
                
                // Draw symmetric bars growing from center vertical axis
                canvasCtx.fillRect(x, midY - barHeight / 2, barWidth - 2, barHeight);
                
                x += barWidth;
            }
        };
        
        draw();
    }

    function stopVisualizer() {
        if (animationId) {
            cancelAnimationFrame(animationId);
            animationId = null;
        }
        // Restore placeholder design
        drawStaticWave();
    }

    /* ============================================================================
       7. Prediction API calls and animations
       ============================================================================ */
    runInferenceBtn.addEventListener("click", () => {
        if (!selectedAudioFile) return;
        
        // Show loader animations
        const btnText = runInferenceBtn.querySelector(".btn-text");
        const btnLoader = runInferenceBtn.querySelector(".btn-loader");
        btnText.style.display = "none";
        btnLoader.style.display = "inline-flex";
        runInferenceBtn.disabled = true;
        
        let fetchPromise;
        
        if (isUploadedMode) {
            // Send standard Multi-part Form upload data
            const formData = new FormData();
            formData.append("file", selectedAudioFile);
            
            fetchPromise = fetch(API_PREDICT, {
                method: "POST",
                body: formData
            });
        } else {
            // Send JSON reference sample path
            fetchPromise = fetch(API_PREDICT, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ sample_path: selectedAudioFile.path })
            });
        }
        
        fetchPromise
            .then(res => {
                if (!res.ok) {
                    return res.json().then(json => { throw new Error(json.error || "Inference failed") });
                }
                return res.json();
            })
            .then(prediction => {
                renderInferenceResult(prediction);
            })
            .catch(err => {
                alert(`Error Running Model: ${err.message}`);
                console.error("Model Prediction Failure:", err);
            })
            .finally(() => {
                // Restore Button Text
                btnText.style.display = "inline";
                btnLoader.style.display = "none";
                runInferenceBtn.disabled = false;
            });
    });

    function renderInferenceResult(res) {
        // Toggle view panels
        resultBoxEmpty.style.display = "none";
        resultBoxOutput.style.display = "block";
        
        // Update values
        const predictedEmotion = res.emotion;
        const confidencePct = (res.confidence * 100).toFixed(1);
        
        const emotionColor = EMOTION_COLORS[predictedEmotion.toLowerCase()] || "#00f2fe";
        
        const cardContainer = document.getElementById("predicted-emotion-container");
        cardContainer.style.borderColor = `${emotionColor}44`;
        cardContainer.style.boxShadow = `0 10px 30px ${emotionColor}0f`;
        
        const textVal = document.getElementById("res-emotion");
        textVal.innerText = predictedEmotion;
        textVal.style.color = emotionColor;
        
        document.getElementById("res-confidence").innerText = `${confidencePct}%`;
        document.getElementById("res-device").innerText = res.device || "GPU Model Thread";
        
        // Probability bars rendering
        const barList = document.getElementById("probability-bar-list");
        barList.innerHTML = "";
        
        // Sort probabilities highest first
        const sortedProbabilities = Object.entries(res.probabilities)
            .sort((a, b) => b[1] - a[1]);
            
        sortedProbabilities.forEach(([emotion, prob]) => {
            const probPct = (prob * 100).toFixed(1);
            const color = EMOTION_COLORS[emotion.toLowerCase()] || "#999";
            
            const row = document.createElement("div");
            row.className = "probability-bar-row";
            
            row.innerHTML = `
                <div class="probability-labels">
                    <span class="probability-name">${emotion}</span>
                    <span class="probability-value">${probPct}%</span>
                </div>
                <div class="probability-track">
                    <div class="probability-fill" style="background-color: ${color}; width: 0%;"></div>
                </div>
            `;
            
            barList.appendChild(row);
            
            // Animate width triggers on next draw frame
            setTimeout(() => {
                const fill = row.querySelector(".probability-fill");
                if (fill) fill.style.width = `${probPct}%`;
            }, 100);
        });
    }

    /* ============================================================================
       8. Init Runs
       ============================================================================ */
    loadMetrics();
    loadInteractiveConfusionMatrix();
    loadPredictionsList();
    loadSamplesList();
});
