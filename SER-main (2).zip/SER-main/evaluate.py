import os
import torch
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc
from sklearn.preprocessing import label_binarize

from model import MarathiSERModel, EMOTION_LABELS, NUM_EMOTIONS
from dataset import create_data_loaders
from utils import plot_confusion_matrix

def evaluate_model():
    print("Loading test data...")
    # We only care about the test_loader, but we use the existing function
    _, _, test_loader = create_data_loaders(
        data_dir="data/labeled",
        batch_size=16,
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        max_audio_sec=5.0,
        sample_rate=16000,
        num_workers=0,
        seed=42,
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    print("Loading best model...")
    model = MarathiSERModel(
        num_emotions=NUM_EMOTIONS,
        sample_rate=16000,
        dropout=0.5,
        freeze_wav2vec=False
    ).to(device)

    # Load weights
    checkpoint_path = "checkpoints/best_model.pt"
    if not os.path.exists(checkpoint_path):
        print(f"Error: Could not find model checkpoint at {checkpoint_path}")
        return

    model.load_state_dict(torch.load(checkpoint_path, map_location=device))
    model.eval()

    all_preds = []
    all_labels = []
    all_probs = []
    file_paths = [] # Note: our dataloader currently doesn't return file paths, so we will just index them

    print("Running inference on test dataset...")
    with torch.no_grad():
        for i, (waveforms, labels) in enumerate(test_loader):
            waveforms = waveforms.to(device)
            labels = labels.to(device)
            
            logits = model(waveforms)
            probs = torch.nn.functional.softmax(logits, dim=-1)
            preds = probs.argmax(dim=-1)
            
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
            all_probs.extend(probs.cpu().numpy())

    all_preds = np.array(all_preds)
    all_labels = np.array(all_labels)
    all_probs = np.array(all_probs)

    os.makedirs("results", exist_ok=True)

    # 1. Save detailed text report (F1, Accuracy, etc.)
    print("Generating metrics report...")
    report = classification_report(all_labels, all_preds, target_names=EMOTION_LABELS, zero_division=0)
    with open("results/metrics_report.txt", "w") as f:
        f.write("Marathi SER - Test Dataset Evaluation Report\n")
        f.write("==============================================\n\n")
        f.write(report)
    print(report)

    # 2. Save detailed CSV with predictions
    print("Saving detailed predictions to CSV...")
    df = pd.DataFrame({
        "Sample_Index": np.arange(len(all_preds)),
        "True_Label": [EMOTION_LABELS[l] for l in all_labels],
        "Predicted_Label": [EMOTION_LABELS[p] for p in all_preds],
        "Confidence": np.max(all_probs, axis=1)
    })
    df.to_csv("results/test_predictions.csv", index=False)

    # 3. Save Confusion Matrix
    print("Generating graphical confusion matrix...")
    cm = confusion_matrix(all_labels, all_preds)
    plot_confusion_matrix(cm, EMOTION_LABELS, "results/confusion_matrix.png")

    # 4. Save ROC Curve
    print("Generating ROC Curves...")
    # Binarize labels for One-vs-Rest ROC
    y_test_bin = label_binarize(all_labels, classes=np.arange(NUM_EMOTIONS))
    
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    
    for i in range(NUM_EMOTIONS):
        fpr[i], tpr[i], _ = roc_curve(y_test_bin[:, i], all_probs[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
        
    plt.figure(figsize=(10, 8))
    colors = ['blue', 'green', 'red', 'cyan', 'magenta', 'orange']
    for i, color in zip(range(NUM_EMOTIONS), colors):
        plt.plot(fpr[i], tpr[i], color=color, lw=2,
                 label=f'{EMOTION_LABELS[i]} (AUC = {roc_auc[i]:.2f})')
                 
    plt.plot([0, 1], [0, 1], 'k--', lw=2)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve')
    plt.legend(loc="lower right")
    plt.grid(alpha=0.3)
    plt.savefig("results/roc_curve.png", dpi=300, bbox_inches='tight')
    plt.close()

    print("\nSuccess! All evaluation outputs have been saved to the 'results' folder:")
    print(" - results/metrics_report.txt (Accuracy, F1-Score)")
    print(" - results/test_predictions.csv (Raw output file)")
    print(" - results/confusion_matrix.png (Graphical CM)")
    print(" - results/roc_curve.png (Graphical ROC)")

if __name__ == "__main__":
    evaluate_model()
