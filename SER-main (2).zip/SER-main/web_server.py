import os
import re
import glob
import pandas as pd
from flask import Flask, request, jsonify, send_from_directory

from inference import EmotionPredictor

app = Flask(__name__)

# Initialize model predictor
CHECKPOINT_PATH = "checkpoints/best_model.pt"
predictor = None
try:
    print(f"Initializing EmotionPredictor with checkpoint: {CHECKPOINT_PATH}...")
    predictor = EmotionPredictor(checkpoint_path=CHECKPOINT_PATH)
    print("EmotionPredictor initialized successfully.")
except Exception as e:
    print(f"Warning: Failed to load model. Running in offline/dummy prediction mode. Error: {e}")


def parse_metrics_report(filepath):
    """
    Parses results/metrics_report.txt and returns structured JSON
    """
    if not os.path.exists(filepath):
        return None
        
    with open(filepath, "r") as f:
        content = f.read()

    lines = content.split("\n")
    metrics = {
        "classes": {},
        "accuracy": 0.0,
        "macro_avg": {},
        "weighted_avg": {}
    }
    
    # Emotion labels we expect
    target_emotions = {'anger', 'happiness', 'sadness', 'fear', 'neutral', 'surprise'}
    
    for line in lines:
        line_strip = line.strip()
        if not line_strip:
            continue
        
        # Split by multiple whitespaces
        parts = re.split(r'\s{2,}', line_strip)
        if len(parts) < 2:
            # Let's try splitting by single whitespace if parts are joined
            parts = line_strip.split()
            if not parts:
                continue

        # Look for accuracy line
        if parts[0] == "accuracy":
            # format: accuracy   0.81   194
            try:
                metrics["accuracy"] = float(parts[1])
                metrics["total_support"] = int(parts[2])
            except (ValueError, IndexError):
                pass
            continue
            
        # Look for macro avg or weighted avg
        if parts[0] == "macro avg" or (len(parts) > 1 and parts[0] == "macro" and parts[1] == "avg"):
            # format: macro avg  0.81  0.80  0.80  194
            try:
                val_index = 1 if parts[0] == "macro avg" else 2
                metrics["macro_avg"] = {
                    "precision": float(parts[val_index]),
                    "recall": float(parts[val_index+1]),
                    "f1_score": float(parts[val_index+2]),
                    "support": int(parts[val_index+3])
                }
            except (ValueError, IndexError):
                pass
            continue

        if parts[0] == "weighted avg" or (len(parts) > 1 and parts[0] == "weighted" and parts[1] == "avg"):
            try:
                val_index = 1 if parts[0] == "weighted avg" else 2
                metrics["weighted_avg"] = {
                    "precision": float(parts[val_index]),
                    "recall": float(parts[val_index+1]),
                    "f1_score": float(parts[val_index+2]),
                    "support": int(parts[val_index+3])
                }
            except (ValueError, IndexError):
                pass
            continue

        # Look for specific emotions
        # parts[0] is the emotion name
        first_word = parts[0].split()[0]
        if first_word in target_emotions:
            try:
                # format: anger  0.85  0.93  0.89  30
                vals = parts[0].split()
                if len(vals) >= 5:
                    emotion = vals[0]
                    p, r, f, s = float(vals[1]), float(vals[2]), float(vals[3]), int(vals[4])
                else:
                    emotion = first_word
                    remaining = parts[1:] if len(parts) > 1 else vals[1:]
                    if len(remaining) >= 4:
                        p, r, f, s = float(remaining[0]), float(remaining[1]), float(remaining[2]), int(remaining[3])
                    else:
                        # Split entire line
                        all_parts = line_strip.split()
                        emotion = all_parts[0]
                        p, r, f, s = float(all_parts[1]), float(all_parts[2]), float(all_parts[3]), int(all_parts[4])
                
                metrics["classes"][emotion] = {
                    "precision": p,
                    "recall": r,
                    "f1_score": f,
                    "support": s
                }
            except (ValueError, IndexError) as e:
                print(f"Error parsing line '{line}': {e}")
                pass
                
    return metrics


# Serving static HTML/CSS/JS files
@app.route("/")
def index():
    return send_from_directory("web", "index.html")


@app.route("/<path:path>")
def static_files(path):
    return send_from_directory("web", path)


# Serve metric images
@app.route("/api/results/<filename>")
def serve_results(filename):
    return send_from_directory("results", filename)


# Serve raw audio files
@app.route("/api/audio/<emotion>/<filename>")
def serve_audio(emotion, filename):
    directory = os.path.join("data", "labeled", emotion)
    return send_from_directory(directory, filename)


# API: Get parsed metrics
@app.route("/api/metrics", methods=["GET"])
def get_metrics():
    metrics = parse_metrics_report("results/metrics_report.txt")
    if metrics is None:
        return jsonify({"error": "Metrics file not found"}), 404
    return jsonify(metrics)


# API: Get test predictions
@app.route("/api/predictions", methods=["GET"])
def get_predictions():
    csv_path = "results/test_predictions.csv"
    if not os.path.exists(csv_path):
        return jsonify({"error": "Predictions file not found"}), 404

    try:
        df = pd.read_csv(csv_path)
        
        # Simple pagination & search filter via query params
        search = request.args.get("search", "").strip().lower()
        true_label = request.args.get("true_label", "").strip().lower()
        pred_label = request.args.get("pred_label", "").strip().lower()
        
        if search:
            df = df[
                df["True_Label"].str.lower().str.contains(search) | 
                df["Predicted_Label"].str.lower().str.contains(search)
            ]
            
        if true_label:
            df = df[df["True_Label"].str.lower() == true_label]
            
        if pred_label:
            df = df[df["Predicted_Label"].str.lower() == pred_label]
            
        total_count = len(df)
        
        # Sort if requested
        sort_by = request.args.get("sort_by", "Sample_Index")
        sort_order = request.args.get("sort_order", "asc")
        if sort_by in df.columns:
            df = df.sort_values(by=sort_by, ascending=(sort_order == "asc"))
            
        # Pagination
        page = int(request.args.get("page", 1))
        per_page = int(request.args.get("per_page", 15))
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        
        paginated_df = df.iloc[start_idx:end_idx]
        records = paginated_df.to_dict(orient="records")
        
        return jsonify({
            "total": total_count,
            "page": page,
            "per_page": per_page,
            "pages": (total_count + per_page - 1) // per_page,
            "data": records
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# API: Get audio samples available for inference
@app.route("/api/samples", methods=["GET"])
def get_samples():
    emotions = ["anger", "happiness", "sadness", "fear", "neutral", "surprise"]
    samples = []
    
    for emotion in emotions:
        folder = os.path.join("data", "labeled", emotion)
        if os.path.exists(folder):
            files = glob.glob(os.path.join(folder, "*.wav"))
            # Sort files and pick the first 13 from each category to represent samples
            selected_files = sorted(files)[:13]
            for file_path in selected_files:
                filename = os.path.basename(file_path)
                samples.append({
                    "emotion": emotion,
                    "filename": filename,
                    "audio_url": f"/api/audio/{emotion}/{filename}",
                    "path": f"data/labeled/{emotion}/{filename}"
                })
                
    return jsonify(samples)


# API: Predict emotion (from sample path or custom upload)
@app.route("/api/predict", methods=["POST"])
def predict():
    if predictor is None:
        return jsonify({
            "error": "Model is not loaded. Flask is in offline/dummy prediction mode.",
            "emotion": "neutral",
            "confidence": 0.5,
            "probabilities": {
                "anger": 0.1, "happiness": 0.1, "sadness": 0.1,
                "fear": 0.1, "neutral": 0.5, "surprise": 0.1
            }
        }), 503

    try:
        # 1. Parse JSON body (check for sample_path)
        data = request.get_json(silent=True) or {}
        sample_path = data.get("sample_path")
        
        if sample_path:
            # Prevent path traversal security issue
            normalized_path = os.path.normpath(sample_path).replace("\\", "/")
            if not normalized_path.startswith("data/labeled/"):
                return jsonify({"error": "Access denied: Invalid sample path"}), 400
                
            if not os.path.exists(normalized_path):
                return jsonify({"error": f"Audio file not found: {sample_path}"}), 404
                
            result = predictor.predict(normalized_path)
            # Make path absolute-friendly
            result["file"] = os.path.basename(result["file"])
            return jsonify(result)

        # 2. Check for uploaded file
        if "file" in request.files:
            file = request.files["file"]
            if file.filename == "":
                return jsonify({"error": "No selected file"}), 400
                
            if not file.filename.lower().endswith(".wav"):
                return jsonify({"error": "Only WAV audio files are supported"}), 400

            temp_dir = os.path.join("results", "temp_uploads")
            os.makedirs(temp_dir, exist_ok=True)
            temp_path = os.path.join(temp_dir, file.filename)
            file.save(temp_path)
            
            try:
                result = predictor.predict(temp_path)
                result["file"] = file.filename
            finally:
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                    
            return jsonify(result)
            
        return jsonify({"error": "No audio file or valid sample path provided"}), 400
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": f"Inference failed: {str(e)}"}), 500


if __name__ == "__main__":
    # Standard Flask port
    port = int(os.environ.get("PORT", 5000))
    print(f"Starting Speech Emotion Recognition Server on http://0.0.0.0:{port}...")
    app.run(host="0.0.0.0", port=port, debug=False)
