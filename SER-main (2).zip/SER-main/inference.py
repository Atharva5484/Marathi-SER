"""
Marathi Speech Emotion Recognition – Inference Pipeline
=======================================================
Provides:
  - EmotionPredictor class for single-file, batch, and real-time prediction
  - CLI entry point with formatted output
"""

import os
import logging
import argparse
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import numpy as np
import torch
import torch.nn.functional as F

from model import MarathiSERModel, EMOTION_LABELS, NUM_EMOTIONS, SAMPLE_RATE
from dataset import AudioPreprocessor

logger = logging.getLogger(__name__)


class EmotionPredictor:
    """
    Inference wrapper for the trained Marathi SER model.
    
    Args:
        checkpoint_path: Path to a trained model checkpoint (.pt file).
        device: Device to run inference on (auto-detected if None).
        max_audio_sec: Maximum audio length in seconds.
    """

    def __init__(
        self,
        checkpoint_path: str,
        device: str = None,
        max_audio_sec: float = 5.0,
    ):
        # Device
        if device is None:
            if torch.cuda.is_available():
                self.device = torch.device("cuda")
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                self.device = torch.device("mps")
            else:
                self.device = torch.device("cpu")
        else:
            self.device = torch.device(device)

        # Model
        self.model = MarathiSERModel(
            num_emotions=NUM_EMOTIONS,
            sample_rate=SAMPLE_RATE,
            freeze_wav2vec=True,
        )

        # Load checkpoint
        if os.path.exists(checkpoint_path):
            checkpoint = torch.load(checkpoint_path, map_location=self.device)
            # Handle both full checkpoint and state_dict-only saves
            if "model_state_dict" in checkpoint:
                self.model.load_state_dict(checkpoint["model_state_dict"])
            else:
                self.model.load_state_dict(checkpoint)
            logger.info(f"Model loaded from {checkpoint_path}")
        else:
            logger.warning(
                f"Checkpoint not found: {checkpoint_path}. "
                f"Using randomly initialised model."
            )

        self.model.to(self.device)
        self.model.eval()

        # Preprocessor
        self.preprocessor = AudioPreprocessor(
            target_sr=SAMPLE_RATE, max_seconds=max_audio_sec
        )

        self.emotion_labels = EMOTION_LABELS
        logger.info(f"EmotionPredictor ready on {self.device}")

    @torch.no_grad()
    def predict(self, audio_path: str) -> Dict:
        """
        Predict emotion from a single audio file.
        
        Args:
            audio_path: Path to a .wav file.
        
        Returns:
            Dict with:
                - 'emotion': predicted emotion label (str)
                - 'confidence': confidence score (float, 0–1)
                - 'probabilities': dict of emotion → probability
                - 'file': input file path
        """
        waveform = self.preprocessor(audio_path)  # (1, samples)
        waveform = waveform.squeeze(0).unsqueeze(0).to(self.device)  # (1, samples)

        logits = self.model(waveform)              # (1, num_emotions)
        probs = F.softmax(logits, dim=-1)[0]       # (num_emotions,)

        pred_idx = probs.argmax().item()
        pred_label = self.emotion_labels[pred_idx]
        confidence = probs[pred_idx].item()

        prob_dict = {
            label: probs[i].item()
            for i, label in enumerate(self.emotion_labels)
        }

        return {
            "emotion": pred_label,
            "confidence": confidence,
            "probabilities": prob_dict,
            "file": audio_path,
        }

    @torch.no_grad()
    def predict_batch(self, audio_paths: List[str]) -> List[Dict]:
        """
        Predict emotions for a batch of audio files.
        
        Args:
            audio_paths: List of paths to .wav files.
        
        Returns:
            List of prediction dicts (same format as predict()).
        """
        results = []
        for path in audio_paths:
            try:
                result = self.predict(path)
                results.append(result)
            except Exception as e:
                logger.error(f"Error processing {path}: {e}")
                results.append({
                    "emotion": "error",
                    "confidence": 0.0,
                    "probabilities": {},
                    "file": path,
                    "error": str(e),
                })
        return results

    def predict_realtime(self, duration: float = 5.0) -> Dict:
        """
        Record audio from the microphone and predict emotion.
        
        Args:
            duration: Recording duration in seconds.
        
        Returns:
            Prediction dict.
        """
        try:
            import sounddevice as sd
        except ImportError:
            logger.error(
                "sounddevice not installed. Install it with: pip install sounddevice"
            )
            return {"emotion": "error", "confidence": 0.0, "error": "sounddevice not installed"}

        print(f"Recording for {duration} seconds... Speak now!")
        audio = sd.rec(
            int(duration * SAMPLE_RATE),
            samplerate=SAMPLE_RATE,
            channels=1,
            dtype="float32",
        )
        sd.wait()
        print("Recording complete. Processing...")

        waveform = torch.tensor(audio.T, dtype=torch.float32)  # (1, samples)
        # Pad/truncate
        max_samples = int(SAMPLE_RATE * duration)
        if waveform.shape[-1] > max_samples:
            waveform = waveform[:, :max_samples]
        elif waveform.shape[-1] < max_samples:
            waveform = F.pad(waveform, (0, max_samples - waveform.shape[-1]))

        waveform = waveform.squeeze(0).unsqueeze(0).to(self.device)

        with torch.no_grad():
            logits = self.model(waveform)
            probs = F.softmax(logits, dim=-1)[0]

        pred_idx = probs.argmax().item()
        pred_label = self.emotion_labels[pred_idx]
        confidence = probs[pred_idx].item()

        prob_dict = {
            label: probs[i].item()
            for i, label in enumerate(self.emotion_labels)
        }

        return {
            "emotion": pred_label,
            "confidence": confidence,
            "probabilities": prob_dict,
            "source": "microphone",
        }


# ============================================================================
# CLI Helpers
# ============================================================================

def print_prediction(result: Dict) -> None:
    """Pretty-print a prediction result."""
    source = result.get("file", result.get("source", "unknown"))
    print(f"\n{'─' * 50}")
    print(f"  File: {Path(source).name if 'file' in result else source}")
    print(f"  Predicted Emotion: {result['emotion'].upper()}")
    print(f"  Confidence: {result['confidence']:.2%}")
    print(f"  {'─' * 46}")
    print(f"  {'Emotion':<12} {'Probability':>12}")
    print(f"  {'─' * 24}")
    for emotion, prob in sorted(
        result.get("probabilities", {}).items(), key=lambda x: -x[1]
    ):
        bar = "█" * int(prob * 30)
        print(f"  {emotion:<12} {prob:>8.2%}  {bar}")
    print(f"{'─' * 50}")


def main():
    parser = argparse.ArgumentParser(
        description="Marathi Speech Emotion Recognition — Inference"
    )
    parser.add_argument(
        "--checkpoint", required=True, help="Path to model checkpoint (.pt)"
    )
    parser.add_argument("--audio", help="Path to a single .wav file")
    parser.add_argument("--dir", help="Directory of .wav files for batch prediction")
    parser.add_argument(
        "--realtime", action="store_true", help="Real-time prediction from microphone"
    )
    parser.add_argument(
        "--duration", type=float, default=5.0, help="Recording duration for real-time mode"
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    predictor = EmotionPredictor(args.checkpoint)

    if args.audio:
        result = predictor.predict(args.audio)
        print_prediction(result)

    elif args.dir:
        audio_dir = Path(args.dir)
        wav_files = sorted(audio_dir.glob("*.wav"))
        if not wav_files:
            print(f"No .wav files found in {args.dir}")
            return
        print(f"\nProcessing {len(wav_files)} files from {args.dir}...")
        results = predictor.predict_batch([str(f) for f in wav_files])

        # Summary table
        print(f"\n{'=' * 60}")
        print(f"{'File':<30} {'Emotion':<12} {'Confidence':>10}")
        print(f"{'=' * 60}")
        for r in results:
            fname = Path(r["file"]).name[:28]
            print(f"{fname:<30} {r['emotion']:<12} {r['confidence']:>8.2%}")
        print(f"{'=' * 60}")

        # Distribution
        from collections import Counter
        dist = Counter(r["emotion"] for r in results)
        print("\nEmotion distribution:")
        for emotion, count in dist.most_common():
            pct = 100 * count / len(results)
            print(f"  {emotion:<12} {count:>3} ({pct:.1f}%)")

    elif args.realtime:
        result = predictor.predict_realtime(duration=args.duration)
        print_prediction(result)

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
