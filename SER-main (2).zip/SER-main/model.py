"""
Marathi Speech Emotion Recognition – Model Architecture
========================================================
Dual-branch, attention-based architecture combining:
  Branch 1 – Hand-crafted acoustic features  →  BiGRU temporal modelling
  Branch 2 – Self-supervised IndicWav2Vec    →  Transformer contextual embeddings
  Fusion   – Multi-Head Attention (self + cross-attention)
  Classifier – Fully connected layers with BatchNorm + Dropout → Softmax

Target emotions (6 classes):
  0: Anger, 1: Happiness, 2: Sadness, 3: Fear, 4: Neutral, 5: Surprise

Reference: Proposed architecture from the research paper literature review.
"""

import math
import logging
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchaudio
import torchaudio.transforms as T

logger = logging.getLogger(__name__)


# ============================================================================
# Constants
# ============================================================================

EMOTION_LABELS = ["anger", "happiness", "sadness", "neutral"]
NUM_EMOTIONS = len(EMOTION_LABELS)
SAMPLE_RATE = 16000


# ============================================================================
# Branch 1: Hand-Crafted Feature Extractor
# ============================================================================

class HandCraftedFeatureExtractor(nn.Module):
    """
    Extracts a rich set of hand-crafted acoustic features from a waveform.
    
    Features per frame:
        - MFCC (13) + delta (13) + delta-delta (13)  = 39
        - Pitch / F0                                   =  1
        - Energy (RMS)                                 =  1
        - Chroma                                       = 12
        - Spectral Contrast                            =  7
        - Zero-Crossing Rate                           =  1
        - Spectral Roll-off                            =  1
        ------------------------------------------------
        Total                                          = 62
    
    Args:
        sample_rate: Target sample rate (default 16000).
        n_mfcc:      Number of MFCC coefficients (default 13).
        n_fft:       FFT window size (default 400 = 25 ms at 16 kHz).
        hop_length:  Hop size (default 160 = 10 ms at 16 kHz).
        n_mels:      Mel filter-bank size (default 80).
    """

    def __init__(
        self,
        sample_rate: int = SAMPLE_RATE,
        n_mfcc: int = 13,
        n_fft: int = 400,
        hop_length: int = 160,
        n_mels: int = 80,
    ):
        super().__init__()
        self.sample_rate = sample_rate
        self.n_mfcc = n_mfcc
        self.n_fft = n_fft
        self.hop_length = hop_length
        self.n_mels = n_mels

        # torchaudio transforms
        self.mfcc_transform = T.MFCC(
            sample_rate=sample_rate,
            n_mfcc=n_mfcc,
            melkwargs={
                "n_fft": n_fft,
                "hop_length": hop_length,
                "n_mels": n_mels,
            },
        )
        self.spec_transform = T.Spectrogram(
            n_fft=n_fft, hop_length=hop_length, power=2.0
        )
        self.mel_transform = T.MelSpectrogram(
            sample_rate=sample_rate,
            n_fft=n_fft,
            hop_length=hop_length,
            n_mels=n_mels,
        )

    def _compute_delta(self, feat: torch.Tensor, order: int = 1) -> torch.Tensor:
        """Compute delta (or delta-delta) of a feature tensor [C, T]."""
        return torchaudio.functional.compute_deltas(feat)

    def _compute_energy(self, waveform: torch.Tensor) -> torch.Tensor:
        """Frame-level RMS energy  → shape [1, T_frames]."""
        # Use spectrogram power and sum across frequency axis
        spec = self.spec_transform(waveform)          # [1, F, T]
        energy = spec.sum(dim=-2, keepdim=False)       # [1, T]
        energy = torch.sqrt(energy + 1e-10)
        return energy.unsqueeze(0) if energy.dim() == 1 else energy.unsqueeze(0)

    def _compute_zcr(self, waveform: torch.Tensor) -> torch.Tensor:
        """Frame-level zero-crossing rate  → [1, T_frames]."""
        # Unfold into frames
        frame_len = self.n_fft
        hop = self.hop_length
        wav = waveform.squeeze(0)
        # Pad to make even number of frames
        pad_len = (frame_len - wav.shape[0] % hop) % hop
        wav_padded = F.pad(wav, (0, pad_len))
        frames = wav_padded.unfold(0, frame_len, hop)       # [T, frame_len]
        signs = torch.sign(frames)
        sign_diff = torch.abs(signs[:, 1:] - signs[:, :-1])
        zcr = sign_diff.sum(dim=1).float() / (2.0 * frame_len)
        return zcr.unsqueeze(0).unsqueeze(0)                # [1, 1, T]

    def _compute_spectral_contrast(self, waveform: torch.Tensor, n_bands: int = 6) -> torch.Tensor:
        """
        Approximated spectral contrast using sub-band energy differences.
        Returns shape [1, n_bands+1, T_frames].
        """
        spec = self.spec_transform(waveform)                # [1, F, T]
        spec = spec.squeeze(0)                               # [F, T]
        n_freq = spec.shape[0]
        band_size = n_freq // (n_bands + 1)
        contrasts = []
        for i in range(n_bands + 1):
            start = i * band_size
            end = min(start + band_size, n_freq)
            band = spec[start:end, :]                        # [band_size, T]
            peak = band.max(dim=0).values
            valley = band.min(dim=0).values
            contrast = torch.log1p(peak) - torch.log1p(valley)
            contrasts.append(contrast)
        result = torch.stack(contrasts, dim=0)               # [n_bands+1, T]
        return result.unsqueeze(0)                           # [1, n_bands+1, T]

    def _compute_chroma(self, waveform: torch.Tensor) -> torch.Tensor:
        """
        Chroma feature (12 pitch classes) derived from the spectrogram.
        Returns shape [1, 12, T_frames].
        """
        spec = self.spec_transform(waveform).squeeze(0)     # [F, T]
        n_freq = spec.shape[0]
        # Map each frequency bin to a chroma class
        freqs = torch.linspace(0, self.sample_rate / 2, n_freq, device=spec.device)
        # Avoid log(0)
        freqs[0] = freqs[1] / 2
        # Convert Hz to pitch class (0-11)
        pitch_classes = (12 * torch.log2(freqs / 440.0 + 1e-10)) % 12
        pitch_classes = pitch_classes.long().clamp(0, 11)

        chroma = torch.zeros(12, spec.shape[1], device=spec.device)
        for pc in range(12):
            mask = (pitch_classes == pc).float().unsqueeze(1)  # [F, 1]
            chroma[pc] = (spec * mask).sum(dim=0)
        # Normalise per frame
        chroma = chroma / (chroma.sum(dim=0, keepdim=True) + 1e-10)
        return chroma.unsqueeze(0)                            # [1, 12, T]

    def _compute_spectral_rolloff(self, waveform: torch.Tensor, rolloff_pct: float = 0.85) -> torch.Tensor:
        """Spectral roll-off frequency per frame → [1, 1, T_frames]."""
        spec = self.spec_transform(waveform).squeeze(0)      # [F, T]
        total_energy = spec.sum(dim=0, keepdim=True)          # [1, T]
        cumsum = torch.cumsum(spec, dim=0)                    # [F, T]
        threshold = rolloff_pct * total_energy                # [1, T]
        # Find first bin exceeding the threshold
        above = (cumsum >= threshold).float()
        # argmax returns first True
        rolloff_bin = above.argmax(dim=0).float()             # [T]
        # Normalise to [0, 1]
        rolloff_bin = rolloff_bin / spec.shape[0]
        return rolloff_bin.unsqueeze(0).unsqueeze(0)          # [1, 1, T]

    def _compute_pitch(self, waveform: torch.Tensor) -> torch.Tensor:
        """
        Estimate fundamental frequency (F0 / pitch) per frame → [1, 1, T_frames].
        Uses autocorrelation-based pitch detection (vectorized).
        """
        wav = waveform.squeeze(0)
        frame_len = self.n_fft
        hop = self.hop_length
        pad_len = (frame_len - wav.shape[0] % hop) % hop
        wav_padded = F.pad(wav, (0, pad_len))
        frames = wav_padded.unfold(0, frame_len, hop)  # [T, frame_len]

        # Center frames (subtract mean per frame)
        frames_mean = frames.mean(dim=-1, keepdim=True)
        frames = frames - frames_mean

        # Vectorized Autocorrelation using 2D FFT
        # Size for FFT should be 2 * frame_len to prevent circular convolution artifacts
        fft_size = 2 * frame_len
        frames_fft = torch.fft.rfft(frames, n=fft_size, dim=-1)
        power_spectrum = torch.abs(frames_fft) ** 2
        autocorr = torch.fft.irfft(power_spectrum, n=fft_size, dim=-1)[:, :frame_len]

        # Normalize autocorrelation per frame
        autocorr = autocorr / (autocorr[:, :1] + 1e-10)

        # Search range for pitch (50 Hz to 500 Hz)
        min_lag = max(1, int(self.sample_rate / 500))
        max_lag = min(frame_len - 1, int(self.sample_rate / 50))

        if max_lag <= min_lag:
            pitches = torch.zeros(frames.shape[0], dtype=torch.float32, device=waveform.device)
        else:
            segment = autocorr[:, min_lag:max_lag]
            if segment.shape[1] == 0:
                pitches = torch.zeros(frames.shape[0], dtype=torch.float32, device=waveform.device)
            else:
                best_lag = segment.argmax(dim=-1) + min_lag
                pitch_hz = self.sample_rate / best_lag.float()
                pitches = torch.clamp(pitch_hz / 500.0, max=1.0)
        
        return pitches.unsqueeze(0).unsqueeze(0)  # [1, 1, T]

    @torch.no_grad()
    def extract(self, waveform: torch.Tensor) -> torch.Tensor:
        """
        Extract all hand-crafted features from a waveform.
        
        Args:
            waveform: shape [1, num_samples] (mono, at self.sample_rate).
        
        Returns:
            Tensor of shape [T_frames, 62] where T_frames depends on audio length.
        """
        # 1. MFCC + deltas  → [1, 39, T]
        mfcc = self.mfcc_transform(waveform)              # [1, 13, T]
        delta1 = self._compute_delta(mfcc.squeeze(0))      # [13, T]
        delta2 = self._compute_delta(delta1)               # [13, T]
        mfcc_all = torch.cat(
            [mfcc.squeeze(0), delta1, delta2], dim=0
        ).unsqueeze(0)                                     # [1, 39, T]

        n_frames = mfcc_all.shape[-1]

        # 2. Pitch → [1, 1, T]
        pitch = self._compute_pitch(waveform)
        pitch = F.interpolate(pitch.float(), size=n_frames, mode="linear", align_corners=False)

        # 3. Energy → [1, 1, T]
        energy = self._compute_energy(waveform)
        if energy.dim() == 2:
            energy = energy.unsqueeze(0)
        energy = F.interpolate(energy.float(), size=n_frames, mode="linear", align_corners=False)

        # 4. Chroma → [1, 12, T]
        chroma = self._compute_chroma(waveform)
        chroma = F.interpolate(chroma.float(), size=n_frames, mode="linear", align_corners=False)

        # 5. Spectral Contrast → [1, 7, T]
        sc = self._compute_spectral_contrast(waveform)
        sc = F.interpolate(sc.float(), size=n_frames, mode="linear", align_corners=False)

        # 6. ZCR → [1, 1, T]
        zcr = self._compute_zcr(waveform)
        zcr = F.interpolate(zcr.float(), size=n_frames, mode="linear", align_corners=False)

        # 7. Spectral Roll-off → [1, 1, T]
        rolloff = self._compute_spectral_rolloff(waveform)
        rolloff = F.interpolate(rolloff.float(), size=n_frames, mode="linear", align_corners=False)

        # Concatenate all → [1, 62, T]
        features = torch.cat(
            [mfcc_all, pitch, energy, chroma, sc, zcr, rolloff], dim=1
        )                                                   # [1, 62, T]

        # Transpose to [T, 62] (drop batch dim)
        features = features.squeeze(0).transpose(0, 1)      # [T, 62]
        return features


# ============================================================================
# Branch 1: Hand-Crafted Features + BiGRU
# ============================================================================

class Branch1_HandCrafted(nn.Module):
    """
    Branch 1: Processes hand-crafted acoustic features through a 
    bidirectional GRU for temporal modelling.
    
    Input:  (batch, time, 62)    – 62-dim hand-crafted features
    Output: (batch, time, 256)   – temporal representations
    """

    def __init__(
        self,
        input_dim: int = 62,
        hidden_dim: int = 128,
        num_layers: int = 2,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.layer_norm = nn.LayerNorm(hidden_dim)
        self.bigru = nn.GRU(
            input_size=hidden_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        # output dim = hidden_dim * 2 (bidirectional) = 256

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (batch, time, 62)
        Returns:
            (batch, time, 256)
        """
        x = self.input_proj(x)         # (B, T, hidden)
        x = self.layer_norm(x)
        x = F.relu(x)
        output, _ = self.bigru(x)      # (B, T, hidden*2)
        return output


# ============================================================================
# Branch 2: Self-Supervised (Wav2Vec2 / IndicWav2Vec)
# ============================================================================

class Branch2_SelfSupervised(nn.Module):
    """
    Branch 2: Self-supervised encoder using a Wav2Vec2-family model.
    
    Tries to load IndicWav2Vec (ai4bharat) first, falls back to
    facebook/wav2vec2-base if unavailable.
    
    Input:  (batch, num_samples)   – raw waveform at 16 kHz
    Output: (batch, time, 256)     – projected contextual embeddings
    """

    WAV2VEC_MODELS = [
        "facebook/wav2vec2-base",
        "Harveenchadha/vakyansh-wav2vec2-marathi-mrm-100",
        "facebook/wav2vec2-large-xlsr-53",
    ]

    def __init__(self, output_dim: int = 256, freeze: bool = False):
        super().__init__()
        self.wav2vec = None
        self.model_name = None

        # Try loading models in priority order
        for model_name in self.WAV2VEC_MODELS:
            try:
                from transformers import Wav2Vec2Model
                self.wav2vec = Wav2Vec2Model.from_pretrained(model_name)
                self.model_name = model_name
                logger.info(f"Loaded self-supervised model: {model_name}")
                break
            except Exception as e:
                logger.warning(f"Could not load {model_name}: {e}")
                continue

        if self.wav2vec is None:
            logger.warning(
                "No pretrained Wav2Vec2 model available. "
                "Using a lightweight CNN feature encoder as fallback."
            )
            self._build_fallback_encoder(output_dim)
            self._hidden_size = output_dim
        else:
            self._hidden_size = self.wav2vec.config.hidden_size

        # Projection layer to match Branch 1 output dim
        self.projection = nn.Sequential(
            nn.Linear(self._hidden_size, output_dim),
            nn.LayerNorm(output_dim),
            nn.ReLU(),
        )

        if freeze and self.wav2vec is not None:
            self.freeze_encoder()

    def _build_fallback_encoder(self, output_dim: int) -> None:
        """Build a lightweight CNN encoder as fallback when no HF model is available."""
        self.fallback_encoder = nn.Sequential(
            nn.Conv1d(1, 64, kernel_size=10, stride=5, padding=2),
            nn.BatchNorm1d(64),
            nn.GELU(),
            nn.Conv1d(64, 128, kernel_size=8, stride=4, padding=2),
            nn.BatchNorm1d(128),
            nn.GELU(),
            nn.Conv1d(128, 256, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm1d(256),
            nn.GELU(),
            nn.Conv1d(256, output_dim, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm1d(output_dim),
            nn.GELU(),
        )

    def freeze_encoder(self) -> None:
        """Freeze the Wav2Vec2 feature extractor and encoder weights."""
        if self.wav2vec is not None:
            for param in self.wav2vec.parameters():
                param.requires_grad = False
            logger.info("Wav2Vec2 encoder frozen.")

    def unfreeze_encoder(self) -> None:
        """Unfreeze only the top 3 layers of Wav2Vec2 encoder for fine-tuning."""
        if self.wav2vec is not None:
            unfrozen_count = 0
            for name, param in self.wav2vec.named_parameters():
                is_top = False
                for idx in [9, 10, 11]:
                    if f"encoder.layers.{idx}." in name:
                        is_top = True
                        break
                if is_top:
                    param.requires_grad = True
                    unfrozen_count += 1
                else:
                    param.requires_grad = False
            logger.info(f"Wav2Vec2 encoder unfrozen: {unfrozen_count} top-layer parameters enabled for fine-tuning.")

    def forward(self, waveform: torch.Tensor) -> torch.Tensor:
        """
        Args:
            waveform: (batch, num_samples) raw audio at 16 kHz
        Returns:
            (batch, time, 256)
        """
        if self.wav2vec is not None:
            outputs = self.wav2vec(waveform)
            hidden = outputs.last_hidden_state              # (B, T', hidden_size)
        else:
            # Fallback: use CNN encoder
            x = waveform.unsqueeze(1)                       # (B, 1, samples)
            x = self.fallback_encoder(x)                    # (B, out_dim, T')
            hidden = x.transpose(1, 2)                      # (B, T', out_dim)

        projected = self.projection(hidden)                 # (B, T', 256)
        return projected


# ============================================================================
# Multi-Head Attention Fusion
# ============================================================================

class MultiHeadAttentionFusion(nn.Module):
    """
    Multi-Head Attention Fusion module:
      1. Self-attention within each branch (refine frame-level representations)
      2. Cross-attention between branches (attend to complementary info)
      3. Combine and project to a fixed-size fusion vector
    
    Input:  branch1_out (B, T1, D), branch2_out (B, T2, D)
    Output: fused vector (B, fusion_dim)
    """

    def __init__(
        self,
        embed_dim: int = 256,
        num_heads: int = 4,
        fusion_dim: int = 256,
        dropout: float = 0.4,
    ):
        super().__init__()
        # Self-attention for each branch
        self.self_attn_b1 = nn.MultiheadAttention(
            embed_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.self_attn_b2 = nn.MultiheadAttention(
            embed_dim, num_heads, dropout=dropout, batch_first=True
        )

        # Cross-attention: Branch 1 attends to Branch 2 and vice versa
        self.cross_attn_1to2 = nn.MultiheadAttention(
            embed_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.cross_attn_2to1 = nn.MultiheadAttention(
            embed_dim, num_heads, dropout=dropout, batch_first=True
        )

        # Layer norms
        self.norm_b1 = nn.LayerNorm(embed_dim)
        self.norm_b2 = nn.LayerNorm(embed_dim)
        self.norm_cross1 = nn.LayerNorm(embed_dim)
        self.norm_cross2 = nn.LayerNorm(embed_dim)

        # Fusion projection: concat both branches → fusion_dim
        self.fusion_proj = nn.Sequential(
            nn.Linear(embed_dim * 2, fusion_dim),
            nn.LayerNorm(fusion_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(
        self,
        branch1: torch.Tensor,
        branch2: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            branch1: (B, T1, D) from Branch 1 (hand-crafted + BiGRU)
            branch2: (B, T2, D) from Branch 2 (self-supervised)
        Returns:
            (B, fusion_dim) fused representation
        """
        # --- Self-attention ---
        b1_sa, _ = self.self_attn_b1(branch1, branch1, branch1)
        b1_sa = self.norm_b1(branch1 + b1_sa)              # residual

        b2_sa, _ = self.self_attn_b2(branch2, branch2, branch2)
        b2_sa = self.norm_b2(branch2 + b2_sa)              # residual

        # --- Cross-attention ---
        # Branch 1 query, Branch 2 key/value
        b1_cross, _ = self.cross_attn_1to2(b1_sa, b2_sa, b2_sa)
        b1_cross = self.norm_cross1(b1_sa + b1_cross)

        # Branch 2 query, Branch 1 key/value
        b2_cross, _ = self.cross_attn_2to1(b2_sa, b1_sa, b1_sa)
        b2_cross = self.norm_cross2(b2_sa + b2_cross)

        # --- Temporal pooling (mean over time) ---
        b1_pooled = b1_cross.mean(dim=1)                    # (B, D)
        b2_pooled = b2_cross.mean(dim=1)                    # (B, D)

        # --- Concatenate and project ---
        fused = torch.cat([b1_pooled, b2_pooled], dim=-1)   # (B, 2D)
        fused = self.fusion_proj(fused)                     # (B, fusion_dim)
        return fused


# ============================================================================
# Main Model: MarathiSERModel
# ============================================================================

class MarathiSERModel(nn.Module):
    """
    Dual-branch, attention-based model for Marathi Speech Emotion Recognition.
    
    Architecture:
        Raw waveform
            ├── Branch 1: Hand-crafted features → BiGRU
            └── Branch 2: Wav2Vec2 (IndicWav2Vec) → Projection
                    ↓
            Multi-Head Attention Fusion (self + cross attention)
                    ↓
            Fully Connected Layers (BatchNorm + Dropout)
                    ↓
            Softmax Classifier → 6 emotion classes
    
    Args:
        num_emotions:     Number of emotion classes (default 6).
        sample_rate:      Audio sample rate (default 16000).
        branch1_hidden:   BiGRU hidden size (default 128, output 256 bidirectional).
        branch2_output:   Wav2Vec2 projection dim (default 256).
        fusion_dim:       Attention fusion output dim (default 256).
        num_attn_heads:   Multi-head attention heads (default 4).
        dropout:          Dropout rate for classifier (default 0.3).
        freeze_wav2vec:   Whether to freeze Wav2Vec2 initially (default True).
    """

    def __init__(
        self,
        num_emotions: int = NUM_EMOTIONS,
        sample_rate: int = SAMPLE_RATE,
        branch1_hidden: int = 128,
        branch2_output: int = 256,
        fusion_dim: int = 256,
        num_attn_heads: int = 4,
        dropout: float = 0.5,
        freeze_wav2vec: bool = True,
    ):
        super().__init__()
        self.sample_rate = sample_rate
        self.num_emotions = num_emotions

        # Feature extractor (not a nn.Module, operates in no-grad mode)
        self.feature_extractor = HandCraftedFeatureExtractor(sample_rate=sample_rate)

        # Branch 1: Hand-crafted → BiGRU
        self.branch1 = Branch1_HandCrafted(
            input_dim=62,
            hidden_dim=branch1_hidden,
            num_layers=2,
            dropout=0.2,
        )

        # Branch 2: Wav2Vec2 / IndicWav2Vec
        self.branch2 = Branch2_SelfSupervised(
            output_dim=branch2_output,
            freeze=freeze_wav2vec,
        )

        # Ensure both branches output same dim for attention
        branch_dim = branch1_hidden * 2  # bidirectional = 256
        assert branch_dim == branch2_output, (
            f"Branch dims must match: {branch_dim} vs {branch2_output}"
        )

        # Multi-Head Attention Fusion
        self.fusion = MultiHeadAttentionFusion(
            embed_dim=branch_dim,
            num_heads=num_attn_heads,
            fusion_dim=fusion_dim,
            dropout=0.1,
        )

        # Fully Connected Classifier with BatchNorm + Dropout
        self.classifier = nn.Sequential(
            # FC layer 1: 256 → 128
            nn.Linear(fusion_dim, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(dropout),
            # FC layer 2: 128 → 64
            nn.Linear(128, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(dropout),
            # FC layer 3: 64 → num_emotions
            nn.Linear(64, num_emotions),
        )

    def _align_time_dims(
        self, t1: torch.Tensor, t2: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Align the time dimensions of two tensors by interpolating
        the shorter one to match the longer.
        
        Args:
            t1: (B, T1, D)
            t2: (B, T2, D)
        Returns:
            Two tensors with matching time dimension.
        """
        T1, T2 = t1.shape[1], t2.shape[1]
        if T1 == T2:
            return t1, t2

        target_T = min(T1, T2)
        if T1 != target_T:
            # Interpolate t1: (B, T1, D) → (B, D, T1) → interpolate → (B, D, target_T) → (B, target_T, D)
            t1 = t1.transpose(1, 2)
            t1 = F.interpolate(t1, size=target_T, mode="linear", align_corners=False)
            t1 = t1.transpose(1, 2)
        if T2 != target_T:
            t2 = t2.transpose(1, 2)
            t2 = F.interpolate(t2, size=target_T, mode="linear", align_corners=False)
            t2 = t2.transpose(1, 2)
        return t1, t2

    def forward(self, waveform: torch.Tensor) -> torch.Tensor:
        """
        Forward pass: raw waveform → emotion logits.
        
        Args:
            waveform: (batch, num_samples) raw mono audio at 16 kHz
        Returns:
            logits: (batch, num_emotions)
        """
        batch_size = waveform.shape[0]
        device = waveform.device

        # --- Branch 1: Extract hand-crafted features ---
        features_list = []
        for i in range(batch_size):
            wav_i = waveform[i].unsqueeze(0)  # (1, samples)
            feats = self.feature_extractor.extract(wav_i)  # (T, 62)
            features_list.append(feats)

        # Pad to same length within batch
        max_T = max(f.shape[0] for f in features_list)
        padded_features = torch.zeros(batch_size, max_T, 62, device=device)
        for i, f in enumerate(features_list):
            T = f.shape[0]
            padded_features[i, :T, :] = f.to(device)

        branch1_out = self.branch1(padded_features)          # (B, T, 256)

        # --- Branch 2: Self-supervised features ---
        branch2_out = self.branch2(waveform)                 # (B, T', 256)

        # --- Align time dimensions ---
        branch1_out, branch2_out = self._align_time_dims(branch1_out, branch2_out)

        # --- Attention Fusion ---
        fused = self.fusion(branch1_out, branch2_out)        # (B, 256)

        # --- Classification ---
        logits = self.classifier(fused)                      # (B, num_emotions)
        return logits

    def predict(self, waveform: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Convenience method: returns predicted class and probabilities.
        
        Args:
            waveform: (batch, num_samples)
        Returns:
            predicted_class: (batch,) integer labels
            probabilities:   (batch, num_emotions)
        """
        self.eval()
        with torch.no_grad():
            logits = self.forward(waveform)
            probs = F.softmax(logits, dim=-1)
            predicted = probs.argmax(dim=-1)
        return predicted, probs


# ============================================================================
# Standalone test
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("=" * 70)
    print("Marathi SER Model — Architecture Verification")
    print("=" * 70)

    # Create model
    model = MarathiSERModel(
        num_emotions=6,
        sample_rate=16000,
        freeze_wav2vec=True,
    )

    # Count parameters
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"\nTotal parameters:     {total_params:,}")
    print(f"Trainable parameters: {trainable_params:,}")

    # Dummy forward pass (3 seconds of audio, batch of 2)
    dummy_audio = torch.randn(2, 16000 * 3)  # 2 samples, 3 seconds
    print(f"\nInput shape:  {dummy_audio.shape}")

    model.eval()
    with torch.no_grad():
        logits = model(dummy_audio)
    print(f"Output shape: {logits.shape}")
    print(f"Logits:\n{logits}")

    probs = F.softmax(logits, dim=-1)
    print(f"\nProbabilities:\n{probs}")
    predicted = probs.argmax(dim=-1)
    for i, pred in enumerate(predicted):
        print(f"  Sample {i}: {EMOTION_LABELS[pred.item()]} ({probs[i][pred].item():.2%})")

    print("\n✓ Model architecture verification passed!")
