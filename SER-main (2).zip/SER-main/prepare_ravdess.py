import os
import shutil
import zipfile
import requests
from tqdm import tqdm
from pathlib import Path

# Zenodo direct download link for RAVDESS audio-only speech dataset
RAVDESS_URL = "https://zenodo.org/records/1188976/files/Audio_Speech_Actors_01-24.zip"
ZIP_PATH = "ravdess.zip"
EXTRACT_DIR = "ravdess_raw"
LABELED_DIR = Path("data/ravdess_labeled")

# RAVDESS Emotion mapping (Identifier 3)
# 01 = neutral, 02 = calm, 03 = happy, 04 = sad, 05 = angry, 06 = fearful, 07 = disgust, 08 = surprised
EMOTION_MAP = {
    "01": "neutral",
    "02": "neutral",  # Mapping calm to neutral for simplicity
    "03": "happiness",
    "04": "sadness",
    "05": "anger",
    "06": "fear",
    # 07 is disgust, we skip it as it's not in our 6 classes
    "08": "surprise"
}

def download_file(url, filename):
    print(f"Downloading RAVDESS dataset from {url}...")
    response = requests.get(url, stream=True)
    response.raise_for_status()
    total_size = int(response.headers.get('content-length', 0))
    
    with open(filename, 'wb') as file, tqdm(
        desc=filename,
        total=total_size,
        unit='iB',
        unit_scale=True,
        unit_divisor=1024,
    ) as bar:
        for data in response.iter_content(chunk_size=1024):
            size = file.write(data)
            bar.update(size)

def prepare_ravdess():
    # 1. Download
    if not os.path.exists(ZIP_PATH):
        download_file(RAVDESS_URL, ZIP_PATH)
    else:
        print(f"{ZIP_PATH} already exists. Skipping download.")

    # 2. Extract
    print(f"Extracting {ZIP_PATH} to {EXTRACT_DIR}...")
    with zipfile.ZipFile(ZIP_PATH, 'r') as zip_ref:
        zip_ref.extractall(EXTRACT_DIR)

    # 3. Create target directories
    for emotion in EMOTION_MAP.values():
        (LABELED_DIR / emotion).mkdir(parents=True, exist_ok=True)

    # 4. Map files
    print(f"Mapping audio files into {LABELED_DIR}...")
    count = 0
    for root, _, files in os.walk(EXTRACT_DIR):
        for file in files:
            if file.endswith(".wav"):
                # RAVDESS format: 03-01-05-01-02-01-01.wav
                parts = file.split("-")
                if len(parts) == 7:
                    emotion_id = parts[2]
                    if emotion_id in EMOTION_MAP:
                        target_emotion = EMOTION_MAP[emotion_id]
                        src = os.path.join(root, file)
                        dst = LABELED_DIR / target_emotion / file
                        shutil.copy2(src, dst)
                        count += 1
                        
    print(f"\nSuccessfully prepared {count} RAVDESS files into {LABELED_DIR}!")

if __name__ == "__main__":
    prepare_ravdess()
